package ir.obd.app

import kotlin.math.abs
import kotlin.math.sqrt

class ParsedLog(val name: String, val rows: List<Smp>, val present: List<Int>)
class Finding(val tMs: Long, val level: Int, val text: String)

private val IDX_LC = IDX.mapKeys { it.key.lowercase() }
fun mmss(ms: Long) = "%02d:%02d".format(ms / 60000, (ms / 1000) % 60)

private fun parseTime(s: String): Long? {
    val p = s.trim().split(":"); if (p.size != 3) return null
    val h = p[0].toLongOrNull() ?: return null; val m = p[1].toLongOrNull() ?: return null; val sec = p[2].toDoubleOrNull() ?: return null
    return h * 3_600_000 + m * 60_000 + (sec * 1000).toLong()
}

/** خواندن فایل CSV ضبط‌شده: ستون اول time (HH:mm:ss.SSS) و بقیه‌ی ستون‌ها کلید پارامترها */
fun parseCsv(name: String, text: String): ParsedLog? {
    val lines = text.lineSequence().filter { it.isNotBlank() }.iterator()
    if (!lines.hasNext()) return null
    val head = lines.next().trim().trimStart('\uFEFF').split(",").map { it.trim().lowercase() }
    val col = head.mapIndexedNotNull { c, k -> IDX_LC[k]?.let { i -> c to i } }
    if (col.isEmpty()) return null
    val rows = ArrayList<Smp>(); var prev = -1L; var day = 0L; var t0 = -1L
    while (lines.hasNext()) {
        val f = lines.next().split(",")
        val ms = parseTime(f.getOrNull(0) ?: "") ?: continue
        var t = ms + day
        if (prev >= 0 && t < prev - 12 * 3_600_000L) { day += 24 * 3_600_000L; t = ms + day }
        prev = t; if (t0 < 0) t0 = t
        val v = DoubleArray(PIDS.size) { Double.NaN }
        for ((c, i) in col) f.getOrNull(c)?.trim()?.toDoubleOrNull()?.let { v[i] = it }
        rows += Smp(t - t0, v)
    }
    if (rows.size < 2) return null
    return ParsedLog(name, rows, PIDS.indices.filter { i -> rows.any { !it.v[i].isNaN() } })
}

private fun runs(rows: List<Smp>, minMs: Long, cond: (Smp) -> Boolean): List<IntRange> {
    val res = ArrayList<IntRange>(); var s = -1
    for (i in rows.indices) {
        if (cond(rows[i])) { if (s < 0) s = i }
        else if (s >= 0) { if (rows[i - 1].t - rows[s].t >= minMs) res += s..(i - 1); s = -1 }
    }
    if (s >= 0 && rows.last().t - rows[s].t >= minMs) res += s..rows.lastIndex
    return res
}

/** بررسی خودکار فایل ضبط و پیدا کردن لحظه‌های مشکوک */
fun logFindings(rows: List<Smp>): List<Finding> {
    val out = ArrayList<Finding>()
    fun secs(rg: IntRange) = (rows[rg.last].t - rows[rg.first].t) / 1000
    for (rg in runs(rows, 5000) { (it["cool"] ?: 0.0) > 105 }) {
        val mx = rg.maxOf { rows[it]["cool"] ?: 0.0 }
        out += Finding(rows[rg.first].t, 2, "🌡️ دمای آب بیش از ۱۰۵°C (حداکثر %.0f°C) به مدت %d ثانیه".format(mx, secs(rg)))
    }
    for (rg in runs(rows, 3000) { (it["rpm"] ?: 0.0) > 500 && (it["volt"] ?: 99.0) < 11.8 }) {
        val mn = rg.minOf { rows[it]["volt"] ?: 99.0 }
        out += Finding(rows[rg.first].t, 2, "🔋 ولتاژ پایین با موتور روشن (کمترین %.1f V)".format(mn))
    }
    for (rg in runs(rows, 3000) { (it["volt"] ?: 0.0) > 15.0 })
        out += Finding(rows[rg.first].t, 2, "🔋 ولتاژ شارژ بالا (بیش از ۱۵ ولت) به مدت %d ثانیه".format(secs(rg)))
    var i = 0
    while (i < rows.size) {
        val r0 = rows[i]["rpm"] ?: 0.0
        if (r0 > 600) {
            var j = i + 1; var hit = -1
            while (j < rows.size && rows[j].t - rows[i].t <= 3000) { if ((rows[j]["rpm"] ?: 999.0) < 200) { hit = j; break }; j++ }
            if (hit > 0) { out += Finding(rows[hit].t, 2, "⛔ افت/خاموشی ناگهانی موتور (دور از %.0f به %.0f)".format(r0, rows[hit]["rpm"] ?: 0.0)); i = hit + 5; continue }
        }
        i++
    }
    fun diffRuns(a: String, b: String, label: String) {
        for (rg in runs(rows, 1000) { val x = it[a]; val y = it[b]; x != null && y != null && abs(x - y) > 6 }) {
            val mx = rg.maxOf { abs((rows[it][a] ?: 0.0) - (rows[it][b] ?: 0.0)) }
            out += Finding(rows[rg.first].t, 2, "🦶 $label: اختلاف تا %.0f%% به مدت %d ثانیه".format(mx, secs(rg)))
        }
    }
    diffRuns("tps", "tpsb", "ناهمخوانی TPS A/B"); diffRuns("ped", "pedE", "ناهمخوانی پدال D/E")
    for (rg in runs(rows, 20000) { abs(it["ltft"] ?: 0.0) > 10 })
        out += Finding(rows[rg.first].t, 1, "⛽ تنظیم سوخت بلندمدت خارج از محدوده (%+.0f%%)".format(rows[rg.first]["ltft"] ?: 0.0))
    for (rg in runs(rows, 1000) { (it["rpm"] ?: 0.0) > 6500 })
        out += Finding(rows[rg.first].t, 1, "⚡ دور موتور بیش از ۶۵۰۰ به مدت %d ثانیه".format(secs(rg)))
    var s = 0
    while (s < rows.size) {
        var e = s; while (e < rows.size && rows[e].t - rows[s].t < 10_000) e++
        val w = rows.subList(s, e).filter { (it["spd"] ?: 99.0) < 1 && (it["rpm"] ?: 0.0) in 500.0..1500.0 }.map { it["rpm"]!! }
        if (w.size >= 12) {
            val m = w.average(); val sd = sqrt(w.map { (it - m) * (it - m) }.average())
            if (sd > 70) out += Finding(rows[s].t, 1, "〰️ دور آرام ناپایدار (انحراف %.0f rpm) — احتمال لرزش/misfire".format(sd))
        }
        s = maxOf(e, s + 1)
    }
    val hi = rows.filter { (it["rpm"] ?: 0.0) > 1500 && it["o2"] != null }
    if (hi.size >= 30) {
        val o = hi.map { it["o2"]!! }
        if (o.max() - o.min() < 0.1) out += Finding(hi.first().t, 1, "🧪 سنسور اکسیژن تقریباً ثابت است (%.2f V) — احتمال خرابی سنسور/گرمکن".format(o.average()))
    }
    if (out.isEmpty()) out += Finding(0, 0, "✅ با قاعده‌های موجود ناهنجاری مشخصی پیدا نشد")
    out.sortBy { it.tMs }
    return out
}
