package ir.obd.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Vibrator
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Note {
    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private fun ensure(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            nm(c).createNotificationChannel(NotificationChannel("obd", "پایش زنده", NotificationManager.IMPORTANCE_LOW))
            nm(c).createNotificationChannel(NotificationChannel("obd_alert", "هشدارهای خودرو", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) })
        }
    }
    private fun builder(c: Context, ch: String) = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, ch) else Notification.Builder(c)
    private fun open(c: Context) = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
    /** اعلان دائمی؛ با هر به‌روزرسانی مقادیر زنده را حتی با صفحه‌ی خاموش/قفل نشان می‌دهد */
    fun live(c: Context, text: String): Notification {
        ensure(c)
        return builder(c, "obd").setContentTitle("Baloch OBD • پایش زنده").setContentText(text.lineSequence().first())
            .setStyle(Notification.BigTextStyle().bigText(text)).setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open(c)).setOngoing(true).setOnlyAlertOnce(true).build()
    }
    fun alert(c: Context, id: Int, title: String, text: String) {
        try {
            ensure(c)
            val b = builder(c, "obd_alert").setContentTitle(title).setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_notify_error).setContentIntent(open(c)).setAutoCancel(true)
            if (Build.VERSION.SDK_INT < 26) b.setDefaults(Notification.DEFAULT_ALL).setPriority(Notification.PRIORITY_HIGH)
            nm(c).notify(id, b.build())
        } catch (_: Exception) {}
    }
}

/** سرویس پیش‌زمینه: پردازش را زنده نگه می‌دارد تا ضبط با خاموش شدن صفحه یا رفتن به برنامه‌ی دیگر ادامه یابد */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val n = Note.live(this, "در حال اتصال…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE) else startForeground(1, n)
        if (wl == null) wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "obd:rec").apply { acquire() }
        return START_STICKY
    }
    override fun onDestroy() { try { wl?.release() } catch (_: Exception) {}; super.onDestroy() }
}

data class Trip(val t: Long, val km: Double, val l: Double, val max: Double)
data class Ev(val file: File, val title: String, val text: String)
private class Pend(val t0: Long, val codes: List<String>, val kind: String, val before: List<Smp>, val fz: Map<String, Double>, val after: MutableList<Smp> = mutableListOf())

object Hub { @Volatile var vm: ObdVm? = null }
fun obdVm(ctx: Context): ObdVm = Hub.vm ?: synchronized(Hub) { Hub.vm ?: ObdVm(ctx.applicationContext).also { Hub.vm = it } }

/** نکته: ایمنی نخ — وضعیت Compose از نخ IO نوشته می‌شود (مجاز است) */
class ObdVm(private val app: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val c = ObdClient()
    private val prefs = app.getSharedPreferences("obd", 0)
    private val dir = File(app.filesDir, "logs").apply { mkdirs() }
    private val evDir = File(app.filesDir, "events").apply { mkdirs() }
    private val ring = ArrayDeque<Smp>()
    private val tf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private var w: BufferedWriter? = null
    private var job: Job? = null
    @Volatile private var pend: Pend? = null
    private var known: Set<String>? = null
    private var lastAlert = 0L

    var status by mutableStateOf("متصل نیست"); var connected by mutableStateOf(false); var busy by mutableStateOf(false)
    var live by mutableStateOf(Smp(0, DoubleArray(PIDS.size) { Double.NaN })); var lph by mutableStateOf<Double?>(null)
    var tick by mutableIntStateOf(0)
    var dtcs by mutableStateOf<List<String>?>(null); var dtcMode by mutableIntStateOf(3)
    var freeze by mutableStateOf<Map<String, Double>?>(null); var freezeCode by mutableStateOf<String?>(null)
    var info by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var proto by mutableStateOf(prefs.getString("proto", "0")!!)
    var disp by mutableStateOf(prefs.getString("disp", "1.6")!!)
    var coolMax by mutableStateOf(prefs.getString("coolMax", "105")!!)
    var rpmMax by mutableStateOf(prefs.getString("rpmMax", "6000")!!)
    var calib by mutableStateOf(prefs.getFloat("calib", 1f).toDouble())
    var calEst by mutableStateOf(prefs.getFloat("calEst", 0f).toDouble())
    var recOn by mutableStateOf(prefs.getBoolean("recOn", true))
    var recRows by mutableIntStateOf(0); var recFile by mutableStateOf("")
    var alerts by mutableStateOf(emptyList<String>())
    var newEv by mutableStateOf<String?>(null)
    var tripOn by mutableStateOf(false)
    var tKm by mutableStateOf(0.0); var tL by mutableStateOf(0.0); var tMax by mutableStateOf(0.0)
    var trips by mutableStateOf(loadTrips())
    var events by mutableStateOf(loadEvents()); var logs by mutableStateOf(loadLogs())
    var thrDiff by mutableStateOf<Double?>(null); var thrDiffPed by mutableStateOf<Double?>(null); var thrState by mutableIntStateOf(0)
    var thrOn by mutableStateOf(false); var thrReport by mutableStateOf<ThrRes?>(null)
    private val thrBuf = ArrayList<Smp>(); private var badSince = 0L; private var lastThr = 0L; private var lastNote = 0L
    var texts by mutableStateOf<Map<String, String>>(emptyMap())
    val multiSel = mutableStateListOf(IDX["rpm"]!!, IDX["spd"]!!); var singleSel by mutableIntStateOf(IDX["rpm"]!!)
    var fullPoll by mutableStateOf(prefs.getBoolean("fullPoll", false))
    private val defsFile = File(app.filesDir, "ecu_defs.json").also { EcuDb.loadCustom(it) }
    var ecu by mutableStateOf<EcuResult?>(null); var defsMsg by mutableStateOf(""); var supCount by mutableIntStateOf(0)
    var dashAuto by mutableStateOf(prefs.getBoolean("dashAuto", true))
    val dashKeys = mutableStateListOf<String>().apply { addAll((prefs.getString("dashKeys", "") ?: "").split(",").filter { it in IDX }) }
    fun saveDash() { prefs.edit().putBoolean("dashAuto", dashAuto).putString("dashKeys", dashKeys.joinToString(",")).apply() }

    fun save() = prefs.edit().putString("proto", proto).putString("disp", disp).putString("coolMax", coolMax).putString("rpmMax", rpmMax).apply()
    fun recent(n: Int): List<Smp> = synchronized(ring) { ring.takeLast(n) }

    private fun loadTrips(): List<Trip> {
        val a = JSONArray(prefs.getString("trips", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> Trip(o.getLong("t"), o.getDouble("km"), o.getDouble("l"), o.getDouble("max")) } }.reversed()
    }
    private fun loadEvents(): List<Ev> = evDir.listFiles()?.sortedByDescending { it.name }?.map {
        val l = it.readLines(); Ev(it, l.firstOrNull() ?: "", l.drop(1).joinToString("\n"))
    } ?: emptyList()
    private fun loadLogs(): List<File> = dir.listFiles()?.sortedByDescending { it.name } ?: emptyList()

    // ---------- مصرف سوخت ----------
    private fun rawFuel(l: Smp): Double? {
        l["frate"]?.let { return it }
        val maf = l["maf"] ?: run {
            val r = l["rpm"] ?: return null; val m = l["map"] ?: return null
            val imap = r * m / ((l["iat"] ?: 25.0) + 273.15) / 2
            imap / 60 * 0.85 * (num(disp) ?: 1.6) * 28.97 / 8.314
        }
        return maf / (14.7 * 745) * 3600
    }

    // ---------- هشدار ----------
    private fun beep() {
        try { ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 600) } catch (_: Exception) {}
        try { (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(500) } catch (_: Exception) {}
    }
    private fun checkAlerts(l: Smp) {
        val a = mutableListOf<String>()
        val co = l["cool"] ?: 0.0; val rp = l["rpm"] ?: 0.0
        if (co > (num(coolMax) ?: 105.0)) a += "🌡️ دمای موتور بالاست! (%.0f°C) — توقف کنید".format(co)
        if (rp > (num(rpmMax) ?: 6000.0)) a += "⚡ دور موتور بیش از حد مجاز"
        l["volt"]?.let { if (rp > 500 && it < 11.8) a += "🔋 ولتاژ پایین (%.1f V) — باتری/دینام".format(it) }
        alerts = a
        val now = System.currentTimeMillis()
        if (a.isNotEmpty() && now - lastAlert > 8000) { lastAlert = now; beep(); Note.alert(app, 2, "⚠️ هشدار خودرو", a.joinToString("\n")) }
    }

    // ---------- ضبط روی فایل ----------
    @Synchronized private fun openRec() {
        if (!recOn || w != null) return
        val f = File(dir, "obd_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv")
        w = f.bufferedWriter(); w!!.write("time," + PIDS.joinToString(",") { it.key } + "\n"); recFile = f.name; recRows = 0
    }
    @Synchronized private fun writeRow(r: Smp) {
        val x = w ?: return
        x.write(tf.format(Date(r.t)) + "," + r.v.joinToString(",") { if (it.isNaN()) "" else "%.2f".format(Locale.US, it) } + "\n"); recRows++
    }
    @Synchronized private fun flushRec() { try { w?.flush() } catch (_: Exception) {} }
    @Synchronized private fun closeRec() { try { w?.close() } catch (_: Exception) {}; w = null; logs = loadLogs() }
    fun setRec(on: Boolean) {
        recOn = on; prefs.edit().putBoolean("recOn", on).apply()
        if (on && connected) openRec() else if (!on) closeRec()
    }
    fun deleteLog(f: File) { if (f.name != recFile || !connected) f.delete(); logs = loadLogs() }

    // ---------- رویداد خطا ----------
    private fun periodic() {
        val st = c.dtcs(3); val pe = c.dtcs(7)
        val all = (st + pe).toSet(); val prev = known; known = all
        if (prev == null) return
        val fresh = all - prev
        if (fresh.isNotEmpty()) trigger(fresh.toList(), if (fresh.any { it in st }) "خطای ذخیره‌شده‌ی جدید" else "خطای در انتظار (Pending)")
    }
    private fun trigger(codes: List<String>, kind: String) {
        if (pend != null) return
        val t = System.currentTimeMillis()
        val before = synchronized(ring) { ring.filter { it.t >= t - 60_000 } }
        val fz = if (codes.isNotEmpty()) try { c.freeze() } catch (e: Exception) { emptyMap() } else emptyMap()
        pend = Pend(t, codes, kind, before, fz); beep(); Note.alert(app, 3, "📝 رویداد جدید: $kind", codes.joinToString(" ").ifEmpty { "در حال ثبت پارامترها…" })
    }
    fun manualEvent() { if (connected) scope.launch { trigger(emptyList(), "ثبت دستی توسط راننده") } }
    private fun finish(p: Pend) {
        pend = null
        val text = analyze(p.codes, p.kind, p.before, p.after, p.fz)
        val title = (if (p.codes.isEmpty()) "رویداد دستی" else p.codes.joinToString(" ")) + " • " + fa(p.t0)
        File(evDir, "ev_${p.t0}.txt").writeText(title + "\n" + text)
        events = loadEvents(); newEv = title; Note.alert(app, 3, "✅ تحلیل رویداد آماده شد", title)
    }
    fun deleteEvent(e: Ev) { e.file.delete(); events = loadEvents() }

    // ---------- اتصال ----------
    private fun startKeep() { try { val i = Intent(app, KeepAliveService::class.java); if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i) else app.startService(i) } catch (_: Exception) {} }
    private fun stopKeep() { try { app.stopService(Intent(app, KeepAliveService::class.java)) } catch (_: Exception) {} }

    fun disconnect() { job?.cancel(); c.close(); closeRec(); stopKeep(); connected = false; pend = null; status = "متصل نیست" }

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice) {
        job?.cancel(); closeRec(); connected = false; status = "در حال اتصال..."
        job = scope.launch {
            try {
                c.connect(d, proto); c.slowEvery = if (fullPoll) 1 else 8; texts = emptyMap(); connected = true; status = "متصل: ${d.name}"
                known = null; startKeep(); openRec(); supCount = c.sup.size; try { doIdentify() } catch (_: Exception) {}
                var last = System.nanoTime(); var lastSave = last; var lastChk = 0L; var lastFlush = 0L; var tcount = 0
                while (isActive) {
                    val r = c.readAll(); val now = System.nanoTime(); val dt = (now - last) / 1e9; last = now
                    val raw = rawFuel(r); val f = raw?.times(calib)
                    live = r; lph = f
                    if (tcount++ % 6 == 0) texts = texts + c.readTexts(tcount == 1)
                    calEst += (raw ?: 0.0) * dt / 3600
                    if (tripOn) { val v = r["spd"] ?: 0.0; tKm += v * dt / 3600; tL += (f ?: 0.0) * dt / 3600; tMax = maxOf(tMax, v) }
                    synchronized(ring) { ring.addLast(r); while (r.t - ring.first().t > 900_000) ring.removeFirst() }
                    tick++
                    if (recOn) writeRow(r)
                    checkAlerts(r)
                    watchThrottle(r)
                    if (thrOn) synchronized(thrBuf) { thrBuf.add(r) }
                    if (r.t - lastNote > 2000) {
                        lastNote = r.t
                        try { (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, Note.live(app, summary(r))) } catch (_: Exception) {}
                    }
                    pend?.let { p -> if (r.t - p.t0 >= 15_000) finish(p) else p.after += r }
                    if (r.t - lastFlush > 5000) { lastFlush = r.t; flushRec() }
                    if (pend == null && r.t - lastChk > 8000) { lastChk = r.t; periodic() }
                    if (now - lastSave > 30_000_000_000L) { lastSave = now; prefs.edit().putFloat("calEst", calEst.toFloat()).apply() }
                }
            } catch (e: Exception) {
                if (isActive) { connected = false; status = "خطا: ${e.message}"; closeRec(); stopKeep() }
            }
        }
    }

    // ---------- شناسایی ECU ----------
    private fun doIdentify() { val (v, n, cl) = c.ecuStrings(); ecu = EcuDb.identify(v, n, cl, c.info) }
    fun identifyEcu() { scope.launch { busy = true; try { doIdentify() } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false } }
    fun importDefs(text: String): String = try {
        val list = EcuDb.parse(text)
        if (list.isEmpty()) "فایل معتبر است ولی پروفایلی در آن نیست" else { defsFile.writeText(text); EcuDb.custom = list; "✅ ${list.size} پروفایل اضافه شد؛ «شناسایی دوباره» را بزنید" }
    } catch (e: Exception) { "❌ فایل نامعتبر: ${e.message}" }
    fun applyEcuDash() {
        val want = ecu?.matched?.firstOrNull { it.dash.isNotEmpty() }?.dash ?: DASH_GENERIC
        val av = want.filter { k -> IDX[k]?.let { !live.v[it].isNaN() } == true }
        dashKeys.clear(); dashKeys.addAll(if (av.isEmpty()) want else av); dashAuto = false; saveDash()
    }

    fun setFull(b: Boolean) { fullPoll = b; prefs.edit().putBoolean("fullPoll", b).apply(); c.slowEvery = if (b) 1 else 8 }

    // ---------- دریچه گاز برقی ----------
    private fun watchThrottle(r: Smp) {
        val a = r["tps"]; val b = r["tpsb"]; val p = r["ped"]; val e = r["pedE"]
        val d1 = if (a != null && b != null) abs(a - b) else null
        val d2 = if (p != null && e != null) abs(p - e) else null
        thrDiff = d1; thrDiffPed = d2
        val bad = (d1 ?: 0.0) > 6 || (d2 ?: 0.0) > 6
        thrState = if (bad) 2 else if ((d1 ?: 0.0) > 3.5 || (d2 ?: 0.0) > 3.5) 1 else 0
        if (bad) {
            if (badSince == 0L) badSince = r.t
            if (r.t - badSince >= 1000 && r.t - lastThr > 60_000 && pend == null) { lastThr = r.t; trigger(emptyList(), "ناهمخوانی دریچه گاز/پدال (هشدار لحظه‌ای)") }
        } else badSince = 0L
    }
    private fun summary(r: Smp): String {
        fun g(k: String, f: String) = r[k]?.let { f.format(it) } ?: "—"
        return "🚗 ${g("spd", "%.0f")} km/h   ⚙️ ${g("rpm", "%.0f")} rpm\n🌡 ${g("cool", "%.0f")}°C   🔋 ${g("volt", "%.1f")} V" +
            when (thrState) { 2 -> "\n🦶 ناهمخوانی دریچه گاز!"; 1 -> "\n🦶 دریچه: اختلاف کم"; else -> "" }
    }
    fun thrStart() { synchronized(thrBuf) { thrBuf.clear() }; thrReport = null; thrOn = true }
    fun thrStop() {
        thrOn = false
        val rows = synchronized(thrBuf) { thrBuf.toList() }
        val rep = throttleReport(rows); thrReport = rep
        if (rows.size >= 10) { val t = System.currentTimeMillis(); File(evDir, "ev_$t.txt").writeText("گزارش دریچه گاز • " + fa(t) + "\n" + rep.text()); events = loadEvents() }
    }

    // ---------- خطاها و اطلاعات ----------
    fun readDtc(mode: Int) { scope.launch { busy = true; try { dtcs = c.dtcs(mode); dtcMode = mode } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false } }
    fun clearDtc() { scope.launch { busy = true; try { c.clearDtc(); dtcs = emptyList() } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false } }
    fun readFreeze() { scope.launch { busy = true; try { freeze = c.freeze(); freezeCode = c.freezeDtc() } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false } }
    fun loadInfo() {
        scope.launch {
            busy = true
            try {
                val o = mutableListOf<Pair<String, String>>()
                o += "VIN" to (c.vin() ?: "ناموجود (خودرو از آن پشتیبانی نمی‌کند)")
                o += "آداپتور / پروتکل" to c.info
                o += "تعداد PIDهای پشتیبانی‌شده" to c.sup.size.toString()
                c.status()?.let { s ->
                    o += "چراغ چک (MIL)" to (if ((s[0] and 0x80) != 0) "🔴 روشن" else "خاموش")
                    o += "تعداد کدهای خطا" to (s[0] and 0x7F).toString()
                    o += c.readiness(s)
                }
                o += c.misc()
                info = o
            } catch (e: Exception) { status = "خطا: ${e.message}" }
            busy = false
        }
    }

    // ---------- سفر و کالیبراسیون ----------
    fun startTrip() { tKm = 0.0; tL = 0.0; tMax = 0.0; tripOn = true }
    fun stopTrip() {
        tripOn = false
        if (tKm > 0.05) {
            val a = JSONArray(prefs.getString("trips", "[]"))
            a.put(JSONObject().put("t", System.currentTimeMillis()).put("km", tKm).put("l", tL).put("max", tMax))
            prefs.edit().putString("trips", a.toString()).apply(); trips = loadTrips()
        }
    }
    fun resetCal() { calEst = 0.0; prefs.edit().putFloat("calEst", 0f).apply() }
    fun applyCal(actual: Double) {
        if (calEst > 0.5 && actual > 0) { calib = (actual / calEst).coerceIn(0.5, 2.0); prefs.edit().putFloat("calib", calib.toFloat()).apply(); resetCal() }
    }
}
