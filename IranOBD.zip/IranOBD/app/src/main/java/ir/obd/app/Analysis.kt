package ir.obd.app

import kotlin.math.abs
import kotlin.math.sqrt

private class St(val first: Double, val last: Double, val min: Double, val max: Double, val mean: Double) {
    val range get() = max - min
}

/** تحلیل رویداد: پارامترهای ثابت/متغیر قبل از خطا + دلیل احتمالی بر پایه‌ی قاعده‌ها */
fun analyze(codes: List<String>, kind: String, before: List<Smp>, after: List<Smp>, fz: Map<String, Double>): String {
    val sb = StringBuilder()
    sb.append("نوع رویداد: $kind\n")
    codes.forEach { sb.append("• $it — ${dtcDesc(it)}\n") }
    sb.append("نمونه‌ها: ${before.size} قبل از رویداد، ${after.size} بعد از آن\n\n")
    val st = HashMap<String, St>(); val consts = StringBuilder(); val vars = StringBuilder()
    PIDS.forEachIndexed { i, p ->
        if (p.slow && p.key !in DASH_KEYS) return@forEachIndexed
        val xs = before.map { it.v[i] }.filter { !it.isNaN() }
        if (xs.size < 4) return@forEachIndexed
        val s = St(xs.take(3).average(), xs.takeLast(3).average(), xs.min(), xs.max(), xs.average())
        st[p.key] = s
        if (s.range <= p.tol) consts.append("• ${p.name}: %.1f %s\n".format(s.mean, p.unit))
        else {
            val d = when { s.last - s.first > s.range * 0.4 -> "↗ افزایش"; s.first - s.last > s.range * 0.4 -> "↘ کاهش"; else -> "↕ نوسان" }
            vars.append("• ${p.name}: %.1f → %.1f %s  %s (بازه %.1f تا %.1f)\n".format(s.first, s.last, p.unit, d, s.min, s.max))
        }
    }
    sb.append("📌 پارامترهای ثابت (۶۰ ثانیه قبل):\n").append(if (consts.isEmpty()) "—\n" else consts.toString()).append("\n")
    sb.append("📈 پارامترهای متغیر:\n").append(if (vars.isEmpty()) "—\n" else vars.toString()).append("\n")

    if (after.size >= 3) {
        val r = StringBuilder()
        for (k in listOf("rpm", "spd", "cool", "volt")) {
            val i = IDX[k]!!; val a = after.map { it.v[i] }.filter { !it.isNaN() }; val s = st[k]
            if (a.size >= 3 && s != null && abs(a.average() - s.last) > PIDS[i].tol * 2)
                r.append("• ${PIDS[i].name}: %.1f → %.1f\n".format(s.last, a.average()))
        }
        if (r.isNotEmpty()) sb.append("⏱ واکنش بعد از رویداد:\n").append(r.toString()).append("\n")
    }
    if (fz.isNotEmpty()) {
        sb.append("🧊 Freeze Frame (ثبت ECU در لحظه‌ی خطا):\n")
        PIDS.forEach { p -> fz[p.key]?.let { sb.append("• ${p.name}: %.1f %s\n".format(it, p.unit)) } }
        sb.append("\n")
    }

    val c = mutableListOf<String>()
    fun has(vararg p: String) = codes.any { x -> p.any { x.startsWith(it) } }
    fun m(k: String) = st[k]?.mean ?: fz[k]
    st["cool"]?.let { if (it.max > 105) c += "دمای آب تا %.0f°C بالا رفته: فن رادیاتور، ترموستات، سطح آب/ضدیخ، واتر پمپ و درب رادیاتور را بررسی کنید.".format(it.max) }
    st["volt"]?.let { if (it.min < 11.8 && (st["rpm"]?.mean ?: 0.0) > 500) c += "ولتاژ تا %.1f V افت کرده: دینام، تسمه‌ی دینام، اتصال کابل باتری و ارت‌ها را بررسی کنید.".format(it.min) }
    st["rpm"]?.let { if (it.first > 500 && it.min < it.first * 0.4) c += "دور موتور ناگهان افت کرده (%.0f → %.0f): قطع لحظه‌ای سوخت/جرقه یا سنسور دور؛ کانکتورها و رله‌ها را بررسی کنید.".format(it.first, it.min) }
    if (has("P030")) {
        c += "ناهمواری احتراق (misfire): شمع، وایر/کوئل، انژکتور یا نشت هوا. اگر فقط یک سیلندر است، شمع/کوئل آن را با سیلندر دیگر جابه‌جا کنید و ببینید خطا هم جابه‌جا می‌شود."
        st["rpm"]?.let { if (it.range > 250 && it.mean < 1300) c += "نوسان دور (%.0f تا %.0f rpm) لرزش موتور را تأیید می‌کند.".format(it.min, it.max) }
        m("stft")?.let { if (abs(it) > 10) c += "تریم کوتاه‌مدت %+.0f%% است؛ مخلوط نامناسب می‌تواند عامل misfire باشد.".format(it) }
        st["cool"]?.let { if (it.mean < 60) c += "موتور هنوز سرد بود (%.0f°C)؛ misfire در حالت سرد معمولاً به شمع، انژکتور یا کیفیت بنزین مربوط است.".format(it.mean) }
    }
    if (has("P0171")) { val t = m("ltft") ?: m("stft"); c += if (t != null && t > 8) "مخلوط رقیق تأیید شد (تریم %+.0f%%): نشت هوا (شیلنگ‌ها/منیفولد)، کثیفی MAF/MAP، فشار کم پمپ بنزین یا انژکتور گرفته.".format(t) else "مخلوط رقیق ثبت شده ولی تریم ۶۰ ثانیه‌ی قبل غیرعادی نبود؛ احتمالاً در شرایط خاص (شتاب/دور بالا) رخ داده. نشت هوا و فشار بنزین را بررسی کنید." }
    if (has("P0172")) { val t = m("ltft") ?: m("stft"); c += if (t != null && t < -8) "مخلوط غنی تأیید شد (تریم %+.0f%%): سنسور اکسیژن/دما، انژکتور نشتی، فشار زیاد بنزین یا فیلتر هوای گرفته.".format(t) else "مخلوط غنی ثبت شده ولی تریم قبل از آن غیرعادی نبود؛ سنسور اکسیژن و انژکتورها را بررسی کنید." }
    if (has("P0335", "P0336")) c += "سنسور دور میل‌لنگ: کانکتور/سیم، فاصله‌ی سنسور با چرخ‌دنده و خود سنسور؛ علامت معمول: خاموش شدن ناگهانی یا استارت سخت."
    if (has("P0340", "P0341")) c += "سنسور فاز (میل‌سوپاپ): کانکتور/سیم و خود سنسور؛ علامت معمول: استارت دیرهنگام و ناپایداری موتور."
    if (has("P0100", "P0101", "P0102", "P0103")) c += "سنسور جریان هوا (MAF): کثیفی المنت، کانکتور و نشت هوا قبل از سنسور." + (m("maf")?.let { " مقدار ثبت‌شده %.1f g/s (در دور آرام معمولاً ۲ تا ۶).".format(it) } ?: "")
    if (has("P0105", "P0106", "P0107", "P0108")) c += "سنسور MAP: " + (m("map")?.let { "مقدار %.0f kPa (در دور آرام معمولاً ۲۸ تا ۴۵؛ مقدار بالا یعنی نشت خلأ یا سنسور معیوب). ".format(it) } ?: "") + "شیلنگ خلأ و کانکتور را بررسی کنید."
    if (has("P0115", "P0116", "P0117", "P0118")) c += "سنسور دمای آب: " + (st["cool"]?.let { if (it.max > 130 || it.min < -30) "مقدار غیرمنطقی دیده شد (سیم قطع/اتصال کوتاه). " else "" } ?: "") + "سنسور، کانکتور و سیم آن را بررسی کنید."
    if (has("P012")) c += "سنسور دریچه گاز (TPS): " + (st["tps"]?.let { "بازه‌ی %.0f تا %.0f%%؛ اگر بدون فشردن پدال تغییر می‌کند، سنسور یا کانکتور مشکل دارد. ".format(it.min, it.max) } ?: "") + "دریچه گاز را هم تمیز کنید."
    if (has("P013", "P014", "P0420")) st["o2"]?.let { c += if (it.range < 0.15) "سنسور اکسیژن تقریباً ثابت است (%.2f V) و سوئیچ نمی‌کند: سنسور، گرمکن یا سیم آن خراب است.".format(it.mean) else "سنسور اکسیژن فعال است (%.2f تا %.2f V)؛ اگر P0420 دارید، کاتالیست فرسوده محتمل‌تر از سنسور است.".format(it.min, it.max) }
    if (has("P050")) c += "سنسور سرعت: سنسور، سیم‌کشی و ماژول را بررسی کنید." + (st["spd"]?.let { if (it.max < 1 && (st["rpm"]?.mean ?: 0.0) > 1500) " سرعت صفر ثبت شده در حالی که دور بالاست." else "" } ?: "")
    if (has("P0505", "P0506", "P0507")) st["rpm"]?.let { c += "دور آرام میانگین %.0f rpm بود (معمول ۷۵۰ تا ۹۰۰): استپر/دریچه‌ی گاز کثیف و نشت هوا را بررسی کنید.".format(it.mean) }
    if (has("P056")) c += "ولتاژ سیستم: باتری، دینام، تسمه و ارت‌ها را بررسی کنید." + (m("volt")?.let { " میانگین ولتاژ %.1f V.".format(it) } ?: "")
    if (has("P044", "P045")) c += "سیستم تبخیر سوخت: ابتدا درب باک (کامل بسته شده؟)، سپس شیر کنیستر و شیلنگ‌ها."
    if (has("P048")) c += "فن خنک‌کننده: فیوز، رله و خود فن را بررسی کنید." + (m("cool")?.let { " دمای آب در این لحظه %.0f°C بود.".format(it) } ?: "")
    if (has("P020")) c += "مدار انژکتور: کانکتور، سیم‌کشی و خود انژکتور یا رله‌ی انژکتور."
    if (has("P035")) c += "مدار کوئل: کانکتور کوئل، شمع و سیم‌کشی."
    if (has("P023", "P0627")) c += "پمپ بنزین: فیوز، رله و پمپ." + (m("fp")?.let { " فشار ثبت‌شده %.0f kPa.".format(it) } ?: "")
    if (has("P060", "P061", "U0")) c += "ECU/ارتباط: ولتاژ باتری، ارت‌ها و کانکتور ECU را بررسی کنید."
    if (has("P07")) c += "گیربکس: سطح و کیفیت روغن، سنسورها و سیم‌کشی گیربکس."
    if (has("P2135")) c += "P2135 یعنی ECU دو سنسور موقعیت دریچه (A و B) را ناهمخوان دیده است؛ علت معمول کثیفی/فرسودگی دریچه و کانکتور آن است."
    if (has("P2138")) c += "P2138 یعنی دو مسیر سنسور پدال گاز با هم نمی‌خوانند؛ پدال یا کانکتور/سیم‌کشی آن را بررسی کنید."
    if (has("P2176")) c += "P2176: بعد از تمیزکاری یا تعویض دریچه، «آموزش دریچه گاز» (Throttle Relearn) لازم است."
    if (has("P2100", "P2101", "P2102", "P2103", "P0638", "P2111", "P2112", "P2119")) c += "موتور/بدنه‌ی دریچه گاز برقی: کثیفی و گیرکردن، فنر یا موتور دریچه، کانکتور و ولتاژ تغذیه؛ دریچه را تمیز و آموزش دهید."
    val thr = throttleReport(before)
    if (thr.level > 0 || has("P012", "P022", "P2")) {
        sb.append("🦶 بررسی دریچه‌ی گاز برقی:\n"); thr.lines.forEach { sb.append("• ${it.first}: ${it.second}\n") }; sb.append("\n")
        if (thr.level > 0) c += thr.causes
    }
    if (c.isEmpty()) c += if (codes.isEmpty()) "با قواعد موجود ناهنجاری مشخصی در ۶۰ ثانیه‌ی قبل دیده نشد. جدول ثابت/متغیر را با حس خودتان (لرزش، تکان، صدا) مقایسه کنید." else "برای این کد قاعده‌ی اختصاصی نداریم. شرح کد را بخوانید و Freeze Frame را با شرایط رانندگی‌تان تطبیق دهید."
    sb.append("🔎 دلیل(های) احتمالی:\n")
    c.forEachIndexed { i, s -> sb.append("${i + 1}) $s\n") }
    sb.append("\n⚠️ این تحلیل بر پایه‌ی قاعده‌ها و داده‌های ثبت‌شده است و قطعی نیست؛ برای تصمیم نهایی با تعمیرکار مشورت کنید.")
    return sb.toString()
}

private fun med(l: List<Double>) = l.sorted()[l.size / 2]

fun batteryReport(rows: List<Smp>): List<Pair<String, String>> {
    val iv = IDX["volt"]!!; val ir = IDX["rpm"]!!
    val pts = rows.filter { !it.v[iv].isNaN() }
    if (pts.size < 5) return listOf("وضعیت" to "داده‌ی ولتاژ کافی نیست؛ وصل شوید و مراحل را انجام دهید.")
    fun rpm(s: Smp) = s.v[ir].takeIf { !it.isNaN() } ?: 0.0
    val o = mutableListOf<Pair<String, String>>()
    val off = pts.filter { rpm(it) < 100 }.map { it.v[iv] }
    val on = pts.filter { rpm(it) > 600 }.map { it.v[iv] }
    val start = pts.indexOfFirst { rpm(it) > 300 }
    var crank: Double? = null
    if (start > 0 && pts.take(start).any { rpm(it) < 100 })
        crank = pts.subList(maxOf(0, start - 2), minOf(pts.size, start + 4)).minOf { it.v[iv] }
    if (off.isNotEmpty()) { val s = med(off); o += "ولتاژ ساکن (موتور خاموش)" to "%.2f V".format(s); o += "وضعیت باتری" to when { s >= 12.4 -> "✅ شارژ خوب"; s >= 12.0 -> "⚠️ نیمه‌شارژ"; else -> "🔴 ضعیف/خالی" } }
    if (crank != null) { o += "کمترین ولتاژ هنگام استارت" to "%.2f V".format(crank); o += "قدرت باتری زیر بار" to when { crank >= 9.6 -> "✅ خوب"; crank >= 9.0 -> "⚠️ مرزی"; else -> "🔴 ضعیف (یا استارتر پرمصرف)" } }
    if (on.isNotEmpty()) { val s = med(on); o += "ولتاژ شارژ (موتور روشن)" to "%.2f V".format(s); o += "وضعیت دینام" to when { s in 13.5..14.8 -> "✅ سالم"; s < 13.2 -> "🔴 شارژ ضعیف (دینام/تسمه/اتصالات)"; s > 15.0 -> "🔴 شارژ بیش‌ازحد (ریگولاتور)"; else -> "⚠️ مرزی" } }
    if (o.isEmpty()) o += "وضعیت" to "هیچ مرحله‌ای تشخیص داده نشد."
    o += "نکته" to "نمونه‌برداری حدود ۳ بار در ثانیه است و ممکن است افت لحظه‌ای استارت را کامل نبیند."
    return o
}

fun idleReport(rows: List<Smp>): List<Pair<String, String>> {
    val x = rows.map { it.v[IDX["rpm"]!!] }.filter { !it.isNaN() }
    if (x.size < 8) return listOf("نتیجه" to "داده‌ی کافی نیست.")
    val mean = x.average(); val sd = sqrt(x.map { (it - mean) * (it - mean) }.average())
    val spd = rows.maxOf { it.v[IDX["spd"]!!].let { s -> if (s.isNaN()) 0.0 else s } }
    val o = mutableListOf("دور میانگین" to "%.0f rpm".format(mean), "انحراف معیار" to "%.0f rpm".format(sd), "بازه" to "%.0f تا %.0f".format(x.min(), x.max()))
    o += "نتیجه" to when {
        spd > 3 -> "خودرو حرکت کرده؛ تست باید در توقف و دنده‌ی خلاص باشد."
        mean > 1300 -> "دور بالاتر از آرام است (موتور سرد یا پدال گاز)."
        sd < 15 -> "✅ دور آرام بسیار پایدار"
        sd < 35 -> "✅ پایدار (طبیعی)"
        sd < 70 -> "⚠️ ناپایدار: شمع/کوئل، دریچه گاز کثیف، استپر یا نشت هوا"
        else -> "🔴 لرزش شدید: احتمال misfire؛ خطاها را بخوانید"
    }
    return o
}


class ThrRes(val lines: List<Pair<String, String>>, val verdict: String, val level: Int, val causes: List<String>) {
    fun text(): String = verdict + "\n\n" + lines.joinToString("\n") { "• ${it.first}: ${it.second}" } +
        "\n\n🔎 دلیل(های) احتمالی:\n" + causes.mapIndexed { i, s -> "${i + 1}) $s" }.joinToString("\n")
}

private class D(val max: Double, val mean: Double, val over: Double, val at: Double?)

/** بررسی دریچه‌ی گاز برقی: هماهنگی TPS A/B، پدال D/E، پیروی از فرمان ECU، پرش‌ها و ... */
fun throttleReport(rows: List<Smp>): ThrRes {
    val iA = IDX["tps"]!!; val iB = IDX["tpsb"]!!; val iP = IDX["ped"]!!; val iE = IDX["pedE"]!!; val iC = IDX["tcmd"]!!
    val iL = IDX["load"]!!; val iR = IDX["rpm"]!!
    val a = rows.map { it.v[iA] }.filter { !it.isNaN() }
    if (a.size < 10) return ThrRes(listOf("وضعیت" to "داده‌ی دریچه گاز کافی نیست"), "ℹ️ داده‌ی کافی نیست", 0,
        listOf("چند ثانیه بیشتر ضبط کنید؛ اگر ECU موقعیت دریچه را از OBD2 نمی‌دهد، این بررسی ممکن نیست."))
    val lines = mutableListOf<Pair<String, String>>(); val causes = mutableListOf<String>(); var level = 0
    fun mk(s: Int) = when (s) { 2 -> "🔴"; 1 -> "⚠️"; else -> "✅" }
    fun lv(x: Int) { if (x > level) level = x }
    fun diff(x: Int, y: Int, th: Double): D? {
        val pr = rows.filter { !it.v[x].isNaN() && !it.v[y].isNaN() }
        if (pr.size < 8) return null
        val d = pr.map { abs(it.v[x] - it.v[y]) }
        val bad = pr.filterIndexed { i, _ -> d[i] > th }
        return D(d.max(), d.average(), bad.size.toDouble() / pr.size, bad.map { it.v[x] }.takeIf { it.isNotEmpty() }?.average())
    }
    fun corr(x: Int, y: Int): Double? {
        val pr = rows.filter { !it.v[x].isNaN() && !it.v[y].isNaN() }; if (pr.size < 10) return null
        val xs = pr.map { it.v[x] }; val ys = pr.map { it.v[y] }; val mx = xs.average(); val my = ys.average()
        val sx = sqrt(xs.sumOf { (it - mx) * (it - mx) }); val sy = sqrt(ys.sumOf { (it - my) * (it - my) })
        return if (sx < 1e-6 || sy < 1e-6) null else xs.indices.sumOf { (xs[it] - mx) * (ys[it] - my) } / (sx * sy)
    }
    val secs = (rows.last().t - rows.first().t) / 1000
    lines += "نمونه‌ها" to "${rows.size} در $secs ثانیه"

    val ab = diff(iA, iB, 6.0)
    if (ab == null) lines += "اختلاف TPS A/B" to "داده‌ی TPS B از ECU دریافت نمی‌شود"
    else {
        val s = if (ab.max > 12 || ab.over > 0.03) 2 else if (ab.max > 6) 1 else 0; lv(s)
        lines += "اختلاف TPS A/B" to "بیشینه %.1f%% • میانگین %.1f%% %s".format(ab.max, ab.mean, mk(s))
        if (s > 0) {
            causes += "TPS A و B هماهنگ نیستند (%.0f%% از زمان اختلاف بیش از ۶٪): بدنه‌ی دریچه کثیف، مسیر مقاومتی فرسوده، کانکتور/سیم‌کشی (مقاومت یا رطوبت) یا ولتاژ ۵ولت مرجع ناپایدار. ابتدا دریچه را با اسپری مخصوص تمیز و کانکتور را بررسی کنید، سپس آموزش دریچه (Throttle Relearn) انجام شود.".format(ab.over * 100)
            ab.at?.let { causes += "اختلاف بیشتر در بازشدن حدود %.0f%% دیده شد؛ فرسودگی مسیر سنسور معمولاً در همان ناحیه از حرکت دریچه است.".format(it) }
        }
    }
    val pe = diff(iP, iE, 6.0)
    if (pe != null) {
        val s = if (pe.max > 12 || pe.over > 0.03) 2 else if (pe.max > 6) 1 else 0; lv(s)
        lines += "اختلاف پدال D/E" to "بیشینه %.1f%% • میانگین %.1f%% %s".format(pe.max, pe.mean, mk(s))
        if (s > 0) causes += "دو مسیر سنسور پدال گاز هماهنگ نیستند: کانکتور پدال، مسیر فرسوده یا سیم‌کشی؛ معمولاً پدال کامل تعویض می‌شود."
    }
    val cp = rows.filter { !it.v[iC].isNaN() && !it.v[iA].isNaN() }
    if (cp.size >= 8) {
        val e = cp.map { it.v[iC] - it.v[iA] }; val me = e.average(); val dev = e.map { abs(it - me) }
        val over = dev.count { it > 12 }.toDouble() / dev.size
        val s = if (over > 0.08) 2 else if (over > 0.03) 1 else 0; lv(s)
        lines += "پیروی دریچه از فرمان ECU" to "انحراف بیشینه %.0f%% (آفست ثابت %.0f%% نادیده گرفته شد) %s".format(dev.max(), me, mk(s))
        if (s > 0) causes += "دریچه از فرمان ECU عقب می‌ماند: موتور/فنر دریچه، گیرکردن (کثیفی) یا لقی دنده‌ها؛ دریچه را تمیز و آموزش دهید."
    }
    val rpa = corr(iP, iA)
    val pRange = rows.map { it.v[iP] }.filter { !it.isNaN() }.let { if (it.isEmpty()) 0.0 else it.max() - it.min() }
    if (rpa != null && pRange > 15) {
        val s = if (rpa < 0.7) 1 else 0; lv(s)
        lines += "همبستگی پدال و دریچه" to "%.2f %s".format(rpa, mk(s))
        if (s > 0) causes += "دریچه از پدال پیروی نمی‌کند: حالت اضطراری (Limp) یا خرابی موتور دریچه/پدال."
    }
    val pr = rows.filter { !it.v[iA].isNaN() }
    var jumps = 0
    for (i in 1 until pr.size) {
        val dA = abs(pr[i].v[iA] - pr[i - 1].v[iA]); val p0 = pr[i - 1].v[iP]; val p1 = pr[i].v[iP]
        if (if (!p0.isNaN() && !p1.isNaN()) (dA > 30 && abs(p1 - p0) < 10) else dA > 60) jumps++
    }
    run { val s = if (jumps >= 3) 1 else 0; lv(s); lines += "پرش ناگهانی بدون حرکت پدال" to "$jumps مورد ${mk(s)}"
        if (s > 0) causes += "سیگنال دریچه بی‌دلیل می‌پرد: قطع و وصل لحظه‌ای کانکتور/سیم یا مسیر سنسور؛ سیم‌ها را تکان دهید و ببینید مقدار می‌پرد یا نه." }
    val amin = a.min(); val amax = a.max()
    lines += "کمترین / بیشترین موقعیت دریچه" to "%.0f%% / %.0f%%".format(amin, amax)
    if (amin > 25) { lv(1); causes += "دریچه هیچ‌وقت کامل بسته نشده (کمترین %.0f%%): کثیفی یا گیرکردن، یا نیاز به آموزش دریچه.".format(amin) }
    val rl = corr(iA, iL)
    if (rl != null && amax - amin > 10) {
        val s = if (rl < 0.4) 1 else 0; lv(s)
        lines += "هماهنگی دریچه با بار موتور" to "%.2f %s".format(rl, mk(s))
        if (s > 0) causes += "بار/جریان هوا با موقعیت دریچه نمی‌خواند: سیگنال TPS ممکن است غلط باشد یا نشت هوا/سنسور MAP مشکل دارد."
    }
    val pmax = rows.map { it.v[iP] }.filter { !it.isNaN() }.maxOrNull(); val rmax = rows.map { it.v[iR] }.filter { !it.isNaN() }.maxOrNull()
    if (pmax != null && rmax != null && pmax > 60 && rmax < 3000) {
        lv(2); lines += "محدودیت دور (Limp)" to "🔴 پدال %.0f%% ولی دور فقط %.0f".format(pmax, rmax)
        causes += "پدال زیاد فشرده شده ولی دور پایین مانده؛ ECU احتمالاً حالت اضطراری (دریچه محدود) را فعال کرده است."
    }
    val verdict = when (level) { 2 -> "🔴 ناهمخوانی/اشکال در سیستم دریچه‌ی گاز دیده شد"; 1 -> "⚠️ نشانه‌ی ضعیف یا نوسان؛ پیگیری شود"; else -> "✅ در این بازه ناهمخوانی دیده نشد" }
    if (level == 0) causes += "اگر خطا فقط حین حرکت رخ می‌دهد، گزارش را درست در لحظه‌ی بروز مشکل بگیرید (دکمه‌ی ثبت یا ضبط خودکار) و ارتعاش/گرمای موتور و کانکتور دریچه را هم بررسی کنید."
    return ThrRes(lines, verdict, level, causes)
}
