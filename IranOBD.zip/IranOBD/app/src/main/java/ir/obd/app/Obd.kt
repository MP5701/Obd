package ir.obd.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class P(
    val id: Int, val key: String, val name: String, val unit: String, val n: Int,
    val max: Float, val tol: Double, val slow: Boolean = false, val f: (List<Int>) -> Double
)

private fun w16(b: List<Int>) = b[0] * 256.0 + b[1]

val PIDS = listOf(
    P(0x0C, "rpm", "دور موتور", "rpm", 2, 8000f, 150.0) { w16(it) / 4 },
    P(0x0D, "spd", "سرعت", "km/h", 1, 220f, 3.0) { it[0].toDouble() },
    P(0x05, "cool", "دمای آب", "°C", 1, 130f, 2.0) { it[0] - 40.0 },
    P(0x04, "load", "بار موتور", "%", 1, 100f, 8.0) { it[0] * 100 / 255.0 },
    P(0x11, "tps", "دریچه گاز", "%", 1, 100f, 4.0) { it[0] * 100 / 255.0 },
    P(0x0B, "map", "فشار مانیفولد (MAP)", "kPa", 1, 255f, 6.0) { it[0].toDouble() },
    P(0x10, "maf", "جریان هوا (MAF)", "g/s", 2, 100f, 1.5) { w16(it) / 100 },
    P(0x06, "stft", "تریم سوخت کوتاه‌مدت", "%", 1, 25f, 5.0) { (it[0] - 128) * 100 / 128.0 },
    P(0x07, "ltft", "تریم سوخت بلندمدت", "%", 1, 25f, 3.0) { (it[0] - 128) * 100 / 128.0 },
    P(0x0E, "adv", "آوانس جرقه", "°", 1, 60f, 4.0) { it[0] / 2.0 - 64 },
    P(0x14, "o2", "سنسور اکسیژن B1S1", "V", 2, 1.1f, 0.15) { it[0] / 200.0 },
    P(0x42, "volt", "ولتاژ باتری", "V", 2, 16f, 0.4) { w16(it) / 1000 },
    P(0x5E, "frate", "نرخ مصرف سوخت", "L/h", 2, 30f, 1.0) { w16(it) / 20 },
    P(0x0F, "iat", "دمای هوای ورودی", "°C", 1, 100f, 3.0, true) { it[0] - 40.0 },
    P(0x0A, "fp", "فشار سوخت", "kPa", 1, 765f, 20.0, true) { it[0] * 3.0 },
    P(0x2F, "fuel", "سطح بنزین", "%", 1, 100f, 3.0, true) { it[0] * 100 / 255.0 },
    P(0x33, "baro", "فشار هوا", "kPa", 1, 255f, 3.0, true) { it[0].toDouble() },
    P(0x46, "amb", "دمای محیط", "°C", 1, 60f, 3.0, true) { it[0] - 40.0 },
    P(0x5C, "oil", "دمای روغن", "°C", 1, 150f, 3.0, true) { it[0] - 40.0 },
)
val IDX = PIDS.mapIndexed { i, p -> p.key to i }.toMap()

/** یک نمونه از همه پارامترها؛ NaN یعنی داده ندارد */
class Smp(val t: Long, val v: DoubleArray) {
    operator fun get(k: String): Double? = IDX[k]?.let { v[it] }?.takeIf { !it.isNaN() }
}

fun dtcCode(a: Int, b: Int) = "PCBU"[a shr 6].toString() + ((a shr 4) and 3) + "%X%02X".format(a and 15, b)

class ObdClient {
    private var sock: BluetoothSocket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null
    private var isCan = false
    private val fails = HashMap<Int, Int>()
    private val last = DoubleArray(PIDS.size) { Double.NaN }
    private var cycle = 0
    val sup = HashSet<Int>()
    var info = ""

    @SuppressLint("MissingPermission")
    fun connect(dev: BluetoothDevice, proto: String) {
        close(); fails.clear(); last.fill(Double.NaN); cycle = 0
        val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect(); sock = s; inp = s.inputStream; out = s.outputStream
        val ver = send("ATZ")
        for (c in listOf("ATE0", "ATL0", "ATS1", "ATH0", "ATSP$proto")) send(c)
        val r = send("0100")
        if (r.contains("UNABLE") || r.contains("ERROR") || r.contains("NO DATA"))
            throw IOException("ECU جواب نداد (سوئیچ باز است؟ پروتکل را عوض کنید)")
        val p = send("ATDPN").filter { it.isLetterOrDigit() }.removePrefix("A")
        isCan = p.firstOrNull()?.let { it in '6'..'9' } ?: false
        loadSupported()
        info = ver.trim() + " | " + send("ATDP")
    }

    fun close() { try { sock?.close() } catch (_: Exception) {}; sock = null; out = null; inp = null }

    @Synchronized
    fun send(cmd: String): String {
        val o = out ?: throw IOException("اتصال قطع است"); val i = inp!!
        while (i.available() > 0) i.read()
        o.write((cmd + "\r").toByteArray()); o.flush()
        val sb = StringBuilder(); val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 8000) {
            if (i.available() > 0) { val c = i.read().toChar(); if (c == '>') break; sb.append(c) } else Thread.sleep(5)
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim()
    }

    private fun bytes(r: String) = r.split(' ')
        .filter { it.length == 2 && it.all { c -> c in '0'..'9' || c in 'A'..'F' } }.map { it.toInt(16) }

    private fun qraw(mode: Int, pid: Int, frame: Boolean = false): List<Int>? {
        val b = bytes(send("%02X%02X".format(mode, pid) + if (frame) "00" else ""))
        val k = (0 until b.size - 1).firstOrNull { b[it] == mode + 0x40 && b[it + 1] == pid } ?: return null
        return b.drop(k + 2 + if (frame) 1 else 0)
    }

    private fun loadSupported() {
        sup.clear(); var base = 0
        while (base <= 0x80) {
            val r = qraw(1, base)?.takeIf { it.size >= 4 } ?: break
            for (i in 0..3) for (bit in 0..7) if ((r[i] and (0x80 shr bit)) != 0) sup += base + i * 8 + bit + 1
            if ((base + 0x20) !in sup) break
            base += 0x20
        }
    }

    private fun atrv() = Regex("[0-9]+\\.?[0-9]*").find(send("ATRV"))?.value?.toDoubleOrNull()

    /** خواندن همه پارامترهای پشتیبانی‌شده (پارامترهای کندتغییر هر ۵ چرخه) */
    fun readAll(): Smp {
        cycle++
        val v = DoubleArray(PIDS.size)
        for ((i, p) in PIDS.withIndex()) {
            var x = last[i]
            val unsupported = sup.isNotEmpty() && p.id !in sup
            if (p.key == "volt" && unsupported) {
                if (cycle % 3 == 0 || x.isNaN()) atrv()?.let { x = it }
            } else if (unsupported || (fails[p.id] ?: 0) >= 3) {
                x = Double.NaN
            } else if (!(p.slow && cycle % 5 != 1)) {
                val d = qraw(1, p.id)?.takeIf { it.size >= p.n }
                if (d == null) fails[p.id] = (fails[p.id] ?: 0) + 1 else { fails[p.id] = 0; x = p.f(d) }
            }
            last[i] = x; v[i] = x
        }
        return Smp(System.currentTimeMillis(), v)
    }

    fun dtcs(mode: Int): List<String> {
        val b = bytes(send("%02X".format(mode)))
        val k = b.indexOf(mode + 0x40); if (k < 0) return emptyList()
        var r = b.drop(k + 1); if (isCan) r = r.drop(1)
        return r.chunked(2).filter { it.size == 2 && (it[0] != 0 || it[1] != 0) }.map { dtcCode(it[0], it[1]) }.distinct()
    }

    fun clearDtc() = send("04")

    /** Freeze Frame: مقادیری که ECU در لحظه‌ی ثبت خطا ذخیره کرده */
    fun freeze(): Map<String, Double> {
        val m = LinkedHashMap<String, Double>()
        for (p in PIDS) {
            if (p.slow || (sup.isNotEmpty() && p.id !in sup)) continue
            qraw(2, p.id, true)?.takeIf { it.size >= p.n }?.let { m[p.key] = p.f(it) }
        }
        return m
    }

    fun freezeDtc(): String? = qraw(2, 2, true)?.takeIf { it.size >= 2 && (it[0] != 0 || it[1] != 0) }?.let { dtcCode(it[0], it[1]) }

    fun status() = qraw(1, 1)?.takeIf { it.size >= 4 }

    fun vin(): String? {
        val b = bytes(send("0902")); val sb = StringBuilder(); var i = 0
        while (i < b.size) {
            if (i + 2 < b.size && b[i] == 0x49 && b[i + 1] == 2 && b[i + 2] in 1..5) { i += 3; continue }
            val ch = b[i]; if (ch in 0x30..0x5A && ch.toChar().isLetterOrDigit()) sb.append(ch.toChar()); i++
        }
        return sb.toString().takeIf { it.length >= 17 }?.take(17)
    }

    fun misc(): List<Pair<String, String>> {
        val o = ArrayList<Pair<String, String>>()
        qraw(1, 0x21)?.takeIf { it.size >= 2 }?.let { o += "مسافت با چراغ چک روشن" to "${it[0] * 256 + it[1]} km" }
        qraw(1, 0x31)?.takeIf { it.size >= 2 }?.let { o += "مسافت از آخرین پاک‌کردن کدها" to "${it[0] * 256 + it[1]} km" }
        qraw(1, 0x1F)?.takeIf { it.size >= 2 }?.let { o += "زمان کارکرد موتور از روشن شدن" to "${(it[0] * 256 + it[1]) / 60} دقیقه" }
        return o
    }

    fun readiness(s: List<Int>): List<Pair<String, String>> {
        val names = listOf("کاتالیست", "کاتالیست گرمکن", "تبخیر سوخت (EVAP)", "هوای ثانویه", "کولر", "سنسور اکسیژن", "گرمکن اکسیژن", "EGR")
        return names.indices.filter { (s[2] and (1 shl it)) != 0 }
            .map { "آمادگی: " + names[it] to if ((s[3] and (1 shl it)) != 0) "⏳ کامل نشده" else "✅ آماده" }
    }
}
