package ir.obd.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** پارامتر عددی مود ۰۱. slow=true یعنی کندتغییر (با تناوب کمتر خوانده می‌شود). id=-1 یعنی مقدار محاسبه‌شده */
class P(
    val id: Int, val key: String, val name: String, val unit: String, val n: Int,
    val max: Float, val tol: Double, val slow: Boolean = false, val f: (List<Int>) -> Double
)

private fun w16(b: List<Int>) = b[0] * 256.0 + b[1]
private fun pct(x: Int) = x * 100 / 255.0
private fun trim(x: Int) = (x - 128) * 100 / 128.0
private fun o2trim(x: Int) = if (x == 255) Double.NaN else trim(x)

val PIDS = listOf(
    P(0x0C, "rpm", "دور موتور", "rpm", 2, 8000f, 150.0) { w16(it) / 4 },
    P(0x0D, "spd", "حسگر سرعت وسیله نقلیه", "km/h", 1, 220f, 3.0) { it[0].toDouble() },
    P(0x05, "cool", "دمای مایع خنک‌کننده موتور", "°C", 1, 130f, 2.0) { it[0] - 40.0 },
    P(0x04, "load", "مقدار بار موتور محاسبه‌شده", "%", 1, 100f, 8.0) { pct(it[0]) },
    P(0x11, "tps", "موقعیت گاز مطلق", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x47, "tpsb", "موقعیت گاز مطلق B", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x48, "tpsc", "موقعیت گاز مطلق C", "%", 1, 100f, 4.0, true) { pct(it[0]) },
    P(0x45, "trel", "موقعیت نسبی گاز", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x49, "ped", "موقعیت پدال گاز D", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x4A, "pedE", "موقعیت پدال گاز E", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x4B, "pedF", "موقعیت پدال گاز F", "%", 1, 100f, 4.0, true) { pct(it[0]) },
    P(0x5A, "pedR", "موقعیت نسبی پدال گاز", "%", 1, 100f, 4.0, true) { pct(it[0]) },
    P(0x4C, "tcmd", "فرمان دریچه (ECU)", "%", 1, 100f, 4.0) { pct(it[0]) },
    P(0x0B, "map", "منیفولد ورودی فشار مطلق", "kPa", 1, 255f, 6.0) { it[0].toDouble() },
    P(0x10, "maf", "نرخ جریان هوا (MAF)", "g/s", 2, 100f, 1.5) { w16(it) / 100 },
    P(-1, "boost", "فشار تقویت محاسبه‌شده (MAP − فشار هوا)", "kPa", 0, 150f, 6.0, true) { 0.0 },
    P(0x06, "stft", "ترم سوخت کوتاه‌مدت - بانک ۱", "%", 1, 25f, 5.0) { trim(it[0]) },
    P(0x07, "ltft", "تنظیم سوخت بلندمدت - بانک ۱", "%", 1, 25f, 3.0) { trim(it[0]) },
    P(0x08, "stft2", "ترم سوخت کوتاه‌مدت - بانک ۲", "%", 1, 25f, 5.0, true) { trim(it[0]) },
    P(0x09, "ltft2", "تنظیم سوخت بلندمدت - بانک ۲", "%", 1, 25f, 3.0, true) { trim(it[0]) },
    P(0x55, "stft1s", "ترم کوتاه‌مدت ثانویه - بانک ۱", "%", 2, 25f, 5.0, true) { trim(it[0]) },
    P(0x55, "stft3s", "ترم کوتاه‌مدت ثانویه - بانک ۳", "%", 2, 25f, 5.0, true) { trim(it[1]) },
    P(0x56, "stft2s", "ترم کوتاه‌مدت ثانویه - بانک ۲", "%", 2, 25f, 5.0, true) { trim(it[0]) },
    P(0x56, "stft4s", "ترم کوتاه‌مدت ثانویه - بانک ۴", "%", 2, 25f, 5.0, true) { trim(it[1]) },
    P(0x57, "ltft1s", "تنظیم بلندمدت ثانویه - بانک ۱", "%", 2, 25f, 3.0, true) { trim(it[0]) },
    P(0x57, "ltft3s", "تنظیم بلندمدت ثانویه - بانک ۳", "%", 2, 25f, 3.0, true) { trim(it[1]) },
    P(0x58, "ltft2s", "تنظیم بلندمدت ثانویه - بانک ۲", "%", 2, 25f, 3.0, true) { trim(it[0]) },
    P(0x58, "ltft4s", "تنظیم بلندمدت ثانویه - بانک ۴", "%", 2, 25f, 3.0, true) { trim(it[1]) },
    P(0x0E, "adv", "تنظیم زمان احتراق (سیلندر ۱)", "°", 1, 60f, 4.0) { it[0] / 2.0 - 64 },
    P(0x14, "o2", "ولتاژ خروجی سنسور اکسیژن - بانک ۱ سنسور ۱", "V", 2, 1.1f, 0.15) { it[0] / 200.0 },
    P(0x14, "o2t", "ترم سوخت کوتاه‌مدت - بانک ۱ سنسور ۱", "%", 2, 25f, 5.0) { o2trim(it[1]) },
    P(0x15, "o2s2", "ولتاژ خروجی سنسور اکسیژن - بانک ۱ سنسور ۲", "V", 2, 1.1f, 0.15, true) { it[0] / 200.0 },
    P(0x15, "o2s2t", "ترم سوخت کوتاه‌مدت - بانک ۱ سنسور ۲", "%", 2, 25f, 5.0, true) { o2trim(it[1]) },
    P(0x18, "o2b2s1", "ولتاژ سنسور اکسیژن - بانک ۲ سنسور ۱", "V", 2, 1.1f, 0.15, true) { it[0] / 200.0 },
    P(0x18, "o2b2s1t", "ترم سوخت کوتاه‌مدت - بانک ۲ سنسور ۱", "%", 2, 25f, 5.0, true) { o2trim(it[1]) },
    P(0x19, "o2b2s2", "ولتاژ سنسور اکسیژن - بانک ۲ سنسور ۲", "V", 2, 1.1f, 0.15, true) { it[0] / 200.0 },
    P(0x19, "o2b2s2t", "ترم سوخت کوتاه‌مدت - بانک ۲ سنسور ۲", "%", 2, 25f, 5.0, true) { o2trim(it[1]) },
    P(0x24, "lam1", "نسبت معادل (λ) - بانک ۱ سنسور ۱", "", 4, 2f, 0.1, true) { w16(it) * 2 / 65536 },
    P(0x24, "lam1v", "ولتاژ سنسور λ - بانک ۱ سنسور ۱", "V", 4, 8f, 0.3, true) { (it[2] * 256.0 + it[3]) * 8 / 65536 },
    P(0x25, "lam2", "نسبت معادل (λ) - بانک ۱ سنسور ۲", "", 4, 2f, 0.1, true) { w16(it) * 2 / 65536 },
    P(0x25, "lam2v", "ولتاژ سنسور λ - بانک ۱ سنسور ۲", "V", 4, 8f, 0.3, true) { (it[2] * 256.0 + it[3]) * 8 / 65536 },
    P(0x44, "cmdlam", "نسبت معادل فرمان‌شده (λ)", "", 2, 2f, 0.1, true) { w16(it) * 2 / 65536 },
    P(0x42, "volt", "ولتاژ باتری/ماژول", "V", 2, 16f, 0.4) { w16(it) / 1000 },
    P(0x5E, "frate", "نرخ مصرف سوخت", "L/h", 2, 30f, 1.0) { w16(it) / 20 },
    P(0x0F, "iat", "دمای هوای ورودی", "°C", 1, 100f, 3.0, true) { it[0] - 40.0 },
    P(0x0A, "fp", "فشار سوخت", "kPa", 1, 765f, 20.0, true) { it[0] * 3.0 },
    P(0x22, "frp", "فشار ریل سوخت (نسبی به خلأ)", "kPa", 2, 5200f, 50.0, true) { w16(it) * 0.079 },
    P(0x23, "frg", "فشار ریل سوخت (گیج)", "kPa", 2, 20000f, 200.0, true) { w16(it) * 10 },
    P(0x59, "frail", "فشار مطلق ریل سوخت", "kPa", 2, 20000f, 200.0, true) { w16(it) * 10 },
    P(0x2F, "fuel", "سطح سوخت", "%", 1, 100f, 3.0, true) { pct(it[0]) },
    P(0x2C, "egr", "فرمان EGR", "%", 1, 100f, 5.0, true) { pct(it[0]) },
    P(0x2D, "egre", "خطای EGR", "%", 1, 100f, 5.0, true) { trim(it[0]) },
    P(0x2E, "purge", "فرمان تبخیر (پرج)", "%", 1, 100f, 5.0, true) { pct(it[0]) },
    P(0x32, "evp", "فشار بخار سیستم تبخیر", "Pa", 2, 8000f, 50.0, true) { (w16(it).toInt().toShort()) / 4.0 },
    P(0x53, "evpa", "فشار مطلق بخار EVAP", "kPa", 2, 330f, 5.0, true) { w16(it) / 200 },
    P(0x33, "baro", "فشار هوا (بارومتریک)", "kPa", 1, 255f, 3.0, true) { it[0].toDouble() },
    P(0x46, "amb", "دمای محیط", "°C", 1, 60f, 3.0, true) { it[0] - 40.0 },
    P(0x5C, "oil", "دمای روغن", "°C", 1, 150f, 3.0, true) { it[0] - 40.0 },
    P(0x3C, "cat11", "دمای کاتالیست - بانک ۱ سنسور ۱", "°C", 2, 1000f, 10.0, true) { w16(it) / 10 - 40 },
    P(0x3D, "cat21", "دمای کاتالیست - بانک ۲ سنسور ۱", "°C", 2, 1000f, 10.0, true) { w16(it) / 10 - 40 },
    P(0x3E, "cat12", "دمای کاتالیست - بانک ۱ سنسور ۲", "°C", 2, 1000f, 10.0, true) { w16(it) / 10 - 40 },
    P(0x3F, "cat22", "دمای کاتالیست - بانک ۲ سنسور ۲", "°C", 2, 1000f, 10.0, true) { w16(it) / 10 - 40 },
    P(0x43, "aload", "مقدار بار مطلق", "%", 2, 100f, 8.0, true) { w16(it) * 100 / 255 },
    P(0x52, "eth", "درصد اتانول سوخت", "%", 1, 100f, 3.0, true) { pct(it[0]) },
    P(0x5D, "itime", "زمان‌بندی پاشش سوخت", "°", 2, 60f, 2.0, true) { w16(it) / 128 - 210 },
    P(0x61, "dtq", "گشتاور درخواستی راننده", "%", 1, 125f, 5.0, true) { it[0] - 125.0 },
    P(0x62, "atq", "گشتاور واقعی موتور", "%", 1, 125f, 5.0, true) { it[0] - 125.0 },
    P(0x63, "rtq", "گشتاور مرجع موتور", "Nm", 2, 500f, 10.0, true) { w16(it) },
    P(0x1F, "run", "زمان کارکرد موتور از استارت", "s", 2, 3600f, 20.0, true) { w16(it) },
    P(0x21, "dmil", "مسافت طی‌شده در حین فعال بودن MIL", "km", 2, 65535f, 1.0, true) { w16(it) },
    P(0x30, "warm", "تعداد گرم‌کردن‌ها از زمان پاک‌سازی DTCها", "", 1, 255f, 1.0, true) { it[0].toDouble() },
    P(0x31, "dclr", "مسافت طی‌شده از زمان پاک شدن DTCها", "km", 2, 65535f, 1.0, true) { w16(it) },
    P(0x4D, "tmil", "زمان کارکرد با MIL فعال", "min", 2, 65535f, 1.0, true) { w16(it) },
    P(0x4E, "tclr", "زمان از پاک شدن DTCها", "min", 2, 65535f, 1.0, true) { w16(it) },
    P(0x4F, "m4a", "حداکثر مقدار برای نسبت معادل", "", 4, 255f, 1.0, true) { it[0].toDouble() },
    P(0x4F, "m4b", "حداکثر مقدار ولتاژ سنسور اکسیژن", "V", 4, 255f, 1.0, true) { it[1].toDouble() },
    P(0x4F, "m4c", "حداکثر مقدار برای جریان سنسور اکسیژن", "mA", 4, 255f, 1.0, true) { it[2].toDouble() },
    P(0x4F, "m4d", "حداکثر مقدار برای فشار مطلق منیفولد ورودی", "kPa", 4, 2550f, 10.0, true) { it[3] * 10.0 },
    P(0x50, "mafmax", "حداکثر مقدار نرخ جریان هوا (MAF)", "g/s", 4, 2550f, 50.0, true) { it[0] * 10.0 },
)
val IDX = PIDS.mapIndexed { i, p -> p.key to i }.toMap()

/** پارامتر متنی (وضعیت‌ها و اطلاعات ثابت). dyn=true یعنی در حین کار تغییر می‌کند */
class TP(val id: Int, val key: String, val name: String, val n: Int, val dyn: Boolean, val f: (List<Int>) -> String)

private fun fuelSt(x: Int) = when (x) {
    0 -> "—"; 1 -> "حلقه باز (موتور سرد)"; 2 -> "حلقه بسته (با سنسور اکسیژن)"; 4 -> "حلقه باز (بار/قطع سوخت)"
    8 -> "حلقه باز (خطای سیستم)"; 16 -> "حلقه بسته (خطای سنسور)"; else -> "نامشخص ($x)"
}
private val OBDS = mapOf(1 to "OBD-II (CARB)", 2 to "OBD (EPA)", 3 to "OBD و OBD-II", 4 to "OBD-I", 5 to "غیر سازگار با OBD", 6 to "EOBD (اروپا)",
    7 to "EOBD و OBD-II", 8 to "EOBD و OBD", 9 to "EOBD و OBD و OBD-II", 10 to "JOBD (ژاپن)", 11 to "JOBD و OBD-II", 12 to "JOBD و EOBD",
    13 to "JOBD و EOBD و OBD-II", 17 to "EMD", 18 to "EMD+", 19 to "HD OBD-C", 20 to "HD OBD", 21 to "WWH-OBD", 28 to "OBDBr-1",
    29 to "OBDBr-2", 30 to "KOBD (کره)", 31 to "IOBD I", 32 to "IOBD II")
private val FUELS = mapOf(1 to "بنزین", 2 to "متانول", 3 to "اتانول", 4 to "دیزل", 5 to "گاز مایع (LPG)", 6 to "گاز طبیعی (CNG)", 7 to "پروپان", 8 to "برقی",
    9 to "دوگانه‌سوز بنزین", 10 to "دوگانه‌سوز متانول", 11 to "دوگانه‌سوز اتانول", 12 to "دوگانه‌سوز LPG", 13 to "دوگانه‌سوز CNG",
    14 to "دوگانه‌سوز پروپان", 15 to "دوگانه‌سوز برق")

val TXT = listOf(
    TP(0x03, "fsa", "وضعیت سیستم سوخت A", 2, true) { fuelSt(it[0]) },
    TP(0x03, "fsb", "وضعیت سیستم سوخت B", 2, true) { fuelSt(it[1]) },
    TP(0x12, "sec", "وضعیت هوای ثانویه", 1, true) { when (it[0]) { 1 -> "بالادست کاتالیست"; 2 -> "پایین‌دست کاتالیست"; 4 -> "هوای بیرون/خاموش"; 8 -> "پمپ روشن (تشخیصی)"; else -> "—" } },
    TP(0x13, "o2loc", "مکان حسگرهای اکسیژن", 1, false) {
        val a = it[0]
        fun bank(sh: Int) = (0..3).filter { i -> ((a shr (sh + i)) and 1) == 1 }.map { i -> i + 1 }.joinToString("،").ifEmpty { "—" }
        "بانک ۱: " + bank(0) + " | بانک ۲: " + bank(4)
    },
    TP(0x1C, "obds", "الزامات OBD برای وسیله نقلیه یا موتور", 1, false) { OBDS[it[0]] ?: "کد ${it[0]}" },
    TP(0x51, "ftype", "نوع سوخت", 1, false) { FUELS[it[0]] ?: "کد ${it[0]}" },
)

/** یک نمونه از همه پارامترها؛ NaN یعنی داده ندارد */
class Smp(val t: Long, val v: DoubleArray) {
    operator fun get(k: String): Double? = IDX[k]?.let { v[it] }?.takeIf { !it.isNaN() }
}

fun dtcCode(a: Int, b: Int) = "PCBU"[a shr 6].toString() + ((a shr 4) and 3) + "%X%02X".format(a and 15, b)

class ObdClient {
    private var sock: BluetoothSocket? = null
    private var inp: InputStream? = null
    private var out: OutputStream? = null
    private var isCan = false
    private val fails = HashMap<Int, Int>()
    private val last = DoubleArray(PIDS.size) { Double.NaN }
    private var cycle = 0
    val sup = HashSet<Int>()
    var info = ""
    /** هر چند چرخه یک‌بار پارامترهای کندتغییر خوانده شوند (۱ = پایش کامل) */
    var slowEvery = 8

    @SuppressLint("MissingPermission")
    fun connect(dev: BluetoothDevice, proto: String) {
        close(); fails.clear(); last.fill(Double.NaN); cycle = 0
        val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
        s.connect(); sock = s; inp = s.inputStream; out = s.outputStream
        val ver = send("ATZ")
        for (c in listOf("ATE0", "ATL0", "ATS1", "ATH0", "ATSP$proto")) send(c)
        val r = send("0100")
        if (r.contains("UNABLE") || r.contains("ERROR") || r.contains("NO DATA"))
            throw IOException("ECU جواب نداد (سوئیچ باز است؟ پروتکل را عوض کنید)")
        val p = send("ATDPN").filter { it.isLetterOrDigit() }.removePrefix("A")
        isCan = p.firstOrNull()?.let { it in '6'..'9' } ?: false
        loadSupported()
        info = ver.trim() + " | " + send("ATDP")
    }

    fun close() { try { sock?.close() } catch (_: Exception) {}; sock = null; out = null; inp = null }

    @Synchronized
    fun send(cmd: String): String {
        val o = out ?: throw IOException("اتصال قطع است"); val i = inp!!
        while (i.available() > 0) i.read()
        o.write((cmd + "\r").toByteArray()); o.flush()
        val sb = StringBuilder(); val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 8000) {
            if (i.available() > 0) { val c = i.read().toChar(); if (c == '>') break; sb.append(c) } else Thread.sleep(5)
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim()
    }

    private fun bytes(r: String) = r.split(' ')
        .filter { it.length == 2 && it.all { c -> c in '0'..'9' || c in 'A'..'F' } }.map { it.toInt(16) }

    private fun qraw(mode: Int, pid: Int, frame: Boolean = false): List<Int>? {
        val b = bytes(send("%02X%02X".format(mode, pid) + if (frame) "00" else ""))
        val k = (0 until b.size - 1).firstOrNull { b[it] == mode + 0x40 && b[it + 1] == pid } ?: return null
        return b.drop(k + 2 + if (frame) 1 else 0)
    }

    private fun loadSupported() {
        sup.clear(); var base = 0
        while (base <= 0x80) {
            val r = qraw(1, base)?.takeIf { it.size >= 4 } ?: break
            for (i in 0..3) for (bit in 0..7) if ((r[i] and (0x80 shr bit)) != 0) sup += base + i * 8 + bit + 1
            if ((base + 0x20) !in sup) break
            base += 0x20
        }
    }

    private fun atrv() = Regex("[0-9]+\\.?[0-9]*").find(send("ATRV"))?.value?.toDoubleOrNull()

    /** خواندن همه پارامترهای پشتیبانی‌شده؛ هر PID در هر چرخه فقط یک‌بار پرسیده می‌شود */
    fun readAll(): Smp {
        cycle++
        val v = DoubleArray(PIDS.size)
        val cache = HashMap<Int, List<Int>?>()
        fun get(id: Int, n: Int): List<Int>? {
            if (cache.containsKey(id)) return cache[id]
            val d = qraw(1, id)?.takeIf { it.size >= n }
            fails[id] = if (d == null) (fails[id] ?: 0) + 1 else 0
            cache[id] = d; return d
        }
        val slowTurn = cycle % slowEvery == 1 % slowEvery
        for ((i, p) in PIDS.withIndex()) {
            if (p.id < 0) { v[i] = Double.NaN; continue }
            var x = last[i]
            val unsupported = sup.isNotEmpty() && p.id !in sup
            if (p.key == "volt" && unsupported) {
                if (cycle % 3 == 0 || x.isNaN()) atrv()?.let { x = it }
            } else if (unsupported || (fails[p.id] ?: 0) >= 3) {
                x = Double.NaN
            } else if (!p.slow || slowTurn) {
                get(p.id, p.n)?.let { x = p.f(it) }
            }
            last[i] = x; v[i] = x
        }
        IDX["boost"]?.let { b ->
            val m = v[IDX["map"]!!]; val bar = v[IDX["baro"]!!]
            v[b] = if (m.isNaN()) Double.NaN else m - (if (bar.isNaN()) 101.3 else bar)
        }
        return Smp(System.currentTimeMillis(), v)
    }

    /** پارامترهای متنی؛ all=false فقط موارد متغیر را می‌خواند */
    fun readTexts(all: Boolean): Map<String, String> {
        val m = LinkedHashMap<String, String>(); val cache = HashMap<Int, List<Int>?>()
        for (t in TXT) {
            if (!all && !t.dyn) continue
            if (sup.isNotEmpty() && t.id !in sup) continue
            val d = if (cache.containsKey(t.id)) cache[t.id] else qraw(1, t.id).also { cache[t.id] = it }
            d?.takeIf { it.size >= t.n }?.let { m[t.key] = t.f(it) }
        }
        return m
    }

    fun dtcs(mode: Int): List<String> {
        val b = bytes(send("%02X".format(mode)))
        val k = b.indexOf(mode + 0x40); if (k < 0) return emptyList()
        var r = b.drop(k + 1); if (isCan) r = r.drop(1)
        return r.chunked(2).filter { it.size == 2 && (it[0] != 0 || it[1] != 0) }.map { dtcCode(it[0], it[1]) }.distinct()
    }

    fun clearDtc() = send("04")

    /** Freeze Frame: مقادیری که ECU در لحظه‌ی ثبت خطا ذخیره کرده */
    fun freeze(): Map<String, Double> {
        val m = LinkedHashMap<String, Double>(); val cache = HashMap<Int, List<Int>?>()
        for (p in PIDS) {
            if (p.id < 0 || p.slow || (sup.isNotEmpty() && p.id !in sup)) continue
            val d = if (cache.containsKey(p.id)) cache[p.id] else qraw(2, p.id, true).also { cache[p.id] = it }
            d?.takeIf { it.size >= p.n }?.let { m[p.key] = p.f(it) }
        }
        return m
    }

    fun freezeDtc(): String? = qraw(2, 2, true)?.takeIf { it.size >= 2 && (it[0] != 0 || it[1] != 0) }?.let { dtcCode(it[0], it[1]) }

    fun status() = qraw(1, 1)?.takeIf { it.size >= 4 }

    fun vin(): String? {
        val b = bytes(send("0902")); val sb = StringBuilder(); var i = 0
        while (i < b.size) {
            if (i + 2 < b.size && b[i] == 0x49 && b[i + 1] == 2 && b[i + 2] in 1..5) { i += 3; continue }
            val ch = b[i]; if (ch in 0x30..0x5A && ch.toChar().isLetterOrDigit()) sb.append(ch.toChar()); i++
        }
        return sb.toString().takeIf { it.length >= 17 }?.take(17)
    }

    fun misc(): List<Pair<String, String>> {
        val o = ArrayList<Pair<String, String>>()
        qraw(1, 0x21)?.takeIf { it.size >= 2 }?.let { o += "مسافت با چراغ چک روشن" to "${it[0] * 256 + it[1]} km" }
        qraw(1, 0x31)?.takeIf { it.size >= 2 }?.let { o += "مسافت از آخرین پاک‌کردن کدها" to "${it[0] * 256 + it[1]} km" }
        qraw(1, 0x1F)?.takeIf { it.size >= 2 }?.let { o += "زمان کارکرد موتور از روشن شدن" to "${(it[0] * 256 + it[1]) / 60} دقیقه" }
        return o
    }

    fun readiness(s: List<Int>): List<Pair<String, String>> {
        val names = listOf("کاتالیست", "کاتالیست گرمکن", "تبخیر سوخت (EVAP)", "هوای ثانویه", "کولر", "سنسور اکسیژن", "گرمکن اکسیژن", "EGR")
        return names.indices.filter { (s[2] and (1 shl it)) != 0 }
            .map { "آمادگی: " + names[it] to if ((s[3] and (1 shl it)) != 0) "⏳ کامل نشده" else "✅ آماده" }
    }
}
