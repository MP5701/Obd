package ir.obd.app

import org.json.JSONObject
import java.io.File

val DASH_GENERIC = listOf("rpm", "spd", "cool", "load", "tps", "map", "maf", "stft", "ltft", "o2", "volt", "iat", "adv")

class EcuProfile(
    val id: String, val title: String, val patterns: List<String>, val wmi: List<String>,
    val notes: String, val dtc: Map<String, String> = emptyMap(), val dash: List<String> = emptyList()
)

class EcuResult(val vin: String?, val name: String?, val cal: String?, val link: String, val matched: List<EcuProfile>, val how: String) {
    val hyundai get() = matched.any { it.id == "hyundai" }
    val title get() = matched.joinToString(" + ") { it.title }
}

/** پایگاه شناسایی ECU: پروفایل‌های داخلی + پروفایل‌هایی که کاربر با فایل JSON اضافه می‌کند */
object EcuDb {
    @Volatile var activeDtc: Map<String, String> = emptyMap()
    @Volatile var activeTitle: String = ""
    @Volatile var custom: List<EcuProfile> = emptyList()

    // WMIهای هیوندا/ایران‌خودرو/پارس‌خودرو از منابع عمومی WMI بررسی شده‌اند
    val builtin = listOf(
        EcuProfile("hyundai", "هیوندای (Hyundai)", listOf("HYUNDAI", "KEFICO"),
            listOf("KMH", "KMF", "KMC", "KME", "KMJ", "KM8", "KMT", "KMU", "NLH", "NLJ", "5NP", "5NM", "5NT", "TMA", "MB2", "MC3", "NA6"),
            "ECU هیوندای معمولاً از تأمین‌کنندگانی مثل Kefico، Bosch، Continental/Siemens یا Delphi است. در مدل‌های جدیدتر معمولاً پروتکل CAN است؛ در مدل‌های قدیمی‌تر ممکن است ISO 9141 یا KWP2000 باشد و اگر «خودکار» وصل نشد، پروتکل ۳ و ۴ و ۵ را دستی امتحان کنید. داده‌ی ABS، ایربگ، گیربکس و بسیاری از کدهای P1xxx اختصاصی هیوندای با پروتکل اختصاصی (مثل GDS) خوانده می‌شود و با OBD2 استاندارد ممکن نیست.",
            emptyMap(), DASH_GENERIC),
        EcuProfile("ikco", "ایران‌خودرو (IKCO / پژو ایران)", listOf("IKCO", "IRAN KHODRO"), listOf("NAA"),
            "VIN با NAA یعنی ساخت ایران‌خودرو. ECU بسته به مدل از خانواده‌های Bosch، Siemens/Continental یا Sagem است. بعضی مدل‌ها همه‌ی PIDهای استاندارد (مثل MAF) را نمی‌دهند؛ در این موارد اپ مصرف را از MAP تخمین می‌زند.",
            emptyMap(), DASH_GENERIC),
        EcuProfile("pars", "پارس‌خودرو", listOf("PARS"), listOf("NAP"),
            "VIN با NAP یعنی ساخت پارس‌خودرو. نوع ECU بسته به مدل فرق می‌کند؛ نام و کد کالیبراسیون را بالا ببینید.", emptyMap(), DASH_GENERIC),
        EcuProfile("bosch", "Bosch", listOf("ME7", "ME9", "ME17", "MED17", "MEV17", "EDC15", "EDC16", "EDC17", "BOSCH"), emptyList(),
            "ECU خانواده‌ی Bosch (ME/MED بنزینی، EDC دیزلی). کدهای P1xxx این خانواده اختصاصی‌اند؛ می‌توانید فایل تعریف ECU اضافه کنید.", emptyMap(), DASH_GENERIC),
        EcuProfile("siemens", "Siemens / Continental", listOf("SIM2K", "SIMOS", "SID", "EMS", "SIEMENS", "VDO", "CONTINENTAL"), emptyList(),
            "ECU خانواده‌ی Siemens/Continental. کدهای P1xxx اختصاصی‌اند؛ برای توضیح آن‌ها فایل تعریف ECU اضافه کنید.", emptyMap(), DASH_GENERIC),
        EcuProfile("delphi", "Delphi", listOf("MT05", "MT22", "MT80", "DCM", "DELPHI"), emptyList(),
            "ECU خانواده‌ی Delphi. کدهای P1xxx اختصاصی‌اند.", emptyMap(), DASH_GENERIC),
        EcuProfile("sagem", "Sagem", listOf("S2000", "S3000", "SL96", "SAGEM"), emptyList(),
            "ECU خانواده‌ی Sagem؛ در مدل‌های قدیمی‌تر ممکن است پروتکل KWP باشد و بعضی PIDها ناموجود.", emptyMap(), DASH_GENERIC),
        EcuProfile("marelli", "Magneti Marelli", listOf("IAW", "MJD", "MARELLI", "MAGNETI"), emptyList(),
            "ECU خانواده‌ی Magneti Marelli. کدهای P1xxx اختصاصی‌اند.", emptyMap(), DASH_GENERIC),
    )
    private val generic = EcuProfile("generic", "ECU استاندارد OBD2", emptyList(), emptyList(),
        "مدل ECU از روی VIN یا نام/کد کالیبراسیون تشخیص داده نشد؛ اپ با PIDهای استاندارد کار می‌کند و پارامترها را از روی PIDهای پشتیبانی‌شده‌ی خود ECU تعیین می‌کند.",
        emptyMap(), DASH_GENERIC)

    fun parse(text: String): List<EcuProfile> {
        val arr = JSONObject(text).getJSONArray("profiles")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            fun strs(k: String) = o.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
            val d = LinkedHashMap<String, String>()
            o.optJSONObject("dtc")?.let { j -> j.keys().forEach { k -> d[k.uppercase()] = j.getString(k) } }
            EcuProfile(o.optString("id", "c$i"), o.optString("title", "پروفایل سفارشی"), strs("patterns"), strs("wmi").map { it.uppercase() }, o.optString("notes", ""), d, strs("dash"))
        }
    }

    fun loadCustom(f: File) { custom = try { if (f.exists()) parse(f.readText()) else emptyList() } catch (_: Exception) { emptyList() } }

    /** تطبیق بر پایه‌ی WMI در VIN و متن نام/کد کالیبراسیون؛ نتیجه حدسی است */
    fun identify(vin: String?, name: String?, cal: String?, link: String): EcuResult {
        val hay = ((name ?: "") + " " + (cal ?: "")).uppercase()
        val w = vin?.take(3)?.uppercase()
        val hits = (custom + builtin).filter { p ->
            (w != null && p.wmi.contains(w)) || p.patterns.any { it.isNotBlank() && hay.contains(it.uppercase()) }
        }
        val matched = hits.ifEmpty { listOf(generic) }
        val how = buildString {
            if (w != null) append("WMI در VIN: $w. ") else append("VIN خوانده نشد. ")
            if (name != null || cal != null) append("متن ECU: ${listOfNotNull(name, cal).joinToString(" / ")}. ") else append("نام/کد کالیبراسیون ECU خوانده نشد. ")
            append(if (hits.isEmpty()) "تطبیقی پیدا نشد." else "تطبیق با ${hits.size} پروفایل.")
        }
        val d = LinkedHashMap<String, String>()
        matched.forEach { p -> p.dtc.forEach { (k, v) -> d.putIfAbsent(k, v) } }
        activeDtc = d; activeTitle = matched.first().title
        return EcuResult(vin, name, cal, link, matched, how)
    }
}
