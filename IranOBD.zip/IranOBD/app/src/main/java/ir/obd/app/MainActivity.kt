@file:OptIn(ExperimentalMaterial3Api::class)

package ir.obd.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF0B1220); val CardBg = Color(0xFF141E33); val Track = Color(0xFF243352)
val Accent = Color(0xFFFF9800); val Cyan = Color(0xFF26C6DA); val Ok = Color(0xFF43A047); val Warn = Color(0xFFFFB300); val Bad = Color(0xFFE53935)
val DASH_KEYS = setOf("tps", "map", "maf", "stft", "ltft", "adv", "o2", "volt", "iat", "fuel", "oil", "amb", "fp", "boost", "frate")
val SIGNED = setOf("stft", "ltft", "stft2", "ltft2", "stft1s", "stft2s", "stft3s", "stft4s", "ltft1s", "ltft2s", "ltft3s", "ltft4s",
    "o2t", "o2s2t", "o2b2s1t", "o2b2s2t", "egre", "adv", "dtq", "atq", "evp", "itime", "boost")
fun lowOf(p: P): Float = if (p.key in SIGNED) -p.max else 0f
fun thin(v: List<Float>, n: Int = 400): List<Float> = if (v.size <= n) v else List(n) { v[it * (v.size - 1) / (n - 1)] }

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, secondary = Cyan, background = Bg, surface = CardBg, surfaceVariant = Track)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

/** تبدیل ارقام فارسی/عربی و جداکننده‌ها به عدد */
fun num(s: String): Double? = s.map {
    when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); '٫', '،', ',' -> '.'; else -> it }
}.joinToString("").toDoubleOrNull()

fun fa(t: Long): String = android.icu.text.SimpleDateFormat("yyyy/MM/dd HH:mm", android.icu.util.ULocale("fa_IR@calendar=persian")).format(java.util.Date(t))

fun shareText(ctx: Context, s: String) = ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s) }, null))
fun shareFile(ctx: Context, f: File) {
    val u = FileProvider.getUriForFile(ctx, "ir.baloch.obd.files", f)
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, null))
}

@Composable
fun GCard(color: Color = CardBg, content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), CardDefaults.cardColors(containerColor = color)) { Column(Modifier.padding(14.dp), content = content) }

@Composable
fun App(vm: ObdVm = obdVm(LocalContext.current)) {
    var tab by remember { mutableIntStateOf(0) }
    var standby by remember { mutableStateOf(false) }
    val act = LocalContext.current as? ComponentActivity
    // حالت استند بای: صفحه بسیار کم‌نور و قابل نمایش روی قفل‌صفحه
    DisposableEffect(standby) {
        act?.let { a ->
            val lp = a.window.attributes
            lp.screenBrightness = if (standby) 0.02f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            a.window.attributes = lp
            if (Build.VERSION.SDK_INT >= 27) a.setShowWhenLocked(standby)
            else if (standby) a.window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
            else a.window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        onDispose { }
    }
    BackHandler(standby) { standby = false }
    if (standby) { StandbyScreen(vm) { standby = false }; return }
    val names = listOf("اتصال", "داشبورد", "خطاها", "ضبط", "بیشتر"); val icons = listOf("🔌", "📊", "⚠️", "🔴", "☰")
    Scaffold(bottomBar = {
        NavigationBar(containerColor = CardBg) { names.forEachIndexed { i, n -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icons[i]) }, label = { Text(n, fontSize = 11.sp) }) } }
    }) { p ->
        Column(Modifier.padding(p).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tab) { 0 -> ConnectTab(vm); 1 -> DashHost(vm) { standby = true }; 2 -> DtcTab(vm); 3 -> RecTab(vm); else -> MoreTab(vm) }
        }
    }
}

@Composable
fun StandbyScreen(vm: ObdVm, onExit: () -> Unit) {
    val l = vm.live
    @Composable fun Big(v: Double?, f: String, u: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(v?.let { f.format(it) } ?: "—", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Cyan.copy(alpha = 0.85f)); Text(u, color = Color.Gray, fontSize = 12.sp)
    }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { onExit() }, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(l["spd"]?.let { "%.0f".format(it) } ?: "—", fontSize = 120.sp, fontWeight = FontWeight.Bold, color = Accent.copy(alpha = 0.85f))
            Text("km/h", color = Color.Gray)
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) { Big(l["rpm"], "%.0f", "rpm"); Big(l["cool"], "%.0f", "°C"); Big(l["volt"], "%.1f", "V") }
            vm.alerts.firstOrNull()?.let { Text(it, color = Bad, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            if (vm.thrState == 2) Text("🦶 ناهمخوانی دریچه گاز!", color = Bad, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (!vm.connected) Text("متصل نیست", color = Color.Gray)
            Text("برای خروج لمس کنید", color = Color(0xFF444444), fontSize = 12.sp)
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ConnectTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val ad = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter }
    var devices by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    fun refresh() { devices = try { ad?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    LaunchedEffect(Unit) {
        val ps = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) ps += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) ps += Manifest.permission.POST_NOTIFICATIONS
        if (ps.isEmpty()) refresh() else perm.launch(ps.toTypedArray())
    }
    Text("Baloch OBD", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Accent)
    GCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (vm.connected) Ok else Bad)); Spacer(Modifier.width(8.dp))
            Text(vm.status, style = MaterialTheme.typography.titleMedium)
        }
        Text("دانگل ELM327 را از تنظیمات بلوتوث گوشی جفت کنید (رمز: 1234 یا 0000)، سوئیچ را باز کنید و دستگاه را انتخاب کنید. بعد از اتصال، ضبط و پایش حتی با خاموش‌شدن صفحه ادامه دارد.", fontSize = 13.sp)
    }
    Text("پروتکل (برای خودروهای قدیمی‌تر ممکن است لازم باشد دستی انتخاب شود):", fontSize = 13.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("0" to "خودکار", "3" to "ISO 9141", "4" to "KWP آهسته", "5" to "KWP سریع", "6" to "CAN")
            .forEach { (k, n) -> FilterChip(selected = vm.proto == k, onClick = { vm.proto = k; vm.save() }, label = { Text(n) }) }
    }
    if (vm.connected) OutlinedButton({ vm.disconnect() }, Modifier.fillMaxWidth()) { Text("قطع اتصال و پایان ضبط") }
    if (devices.isEmpty()) Text("هیچ دستگاه جفت‌شده‌ای پیدا نشد.")
    devices.forEach { d -> Button({ vm.connect(d) }, Modifier.fillMaxWidth()) { Text(d.name ?: d.address) } }
}

@Composable
fun Gauge(value: Double?, max: Float, label: String, unit: String, modifier: Modifier = Modifier, base: Color = Accent, danger: Boolean = false, ts: Int = 28) {
    val frac by animateFloatAsState(((value ?: 0.0).toFloat() / max).coerceIn(0f, 1f), tween(350), label = "g")
    val col = if (danger) Bad else base
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            val sw = size.minDimension * 0.09f; val tl = Offset(sw, sw); val sz = Size(size.width - 2 * sw, size.height - 2 * sw)
            drawArc(Track, 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(col.copy(alpha = 0.25f), 135f, 270f * frac, false, tl, sz, style = Stroke(sw * 1.7f, cap = StrokeCap.Round))
            drawArc(col, 135f, 270f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            val cx = size.width / 2; val cy = size.height / 2; val r1 = size.minDimension / 2 - sw * 2.1f; val r2 = r1 - sw * 0.5f
            for (i in 0..10) {
                val a = Math.toRadians(135.0 + 27.0 * i)
                drawLine(Color(0x55FFFFFF), Offset(cx + (r1 * cos(a)).toFloat(), cy + (r1 * sin(a)).toFloat()), Offset(cx + (r2 * cos(a)).toFloat(), cy + (r2 * sin(a)).toFloat()), strokeWidth = if (i % 5 == 0) 4f else 2f)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.0f".format(it) } ?: "—", fontSize = ts.sp, fontWeight = FontWeight.Bold, color = if (danger) Bad else Color.Unspecified)
            Text("$label $unit", fontSize = (ts / 2.4f).coerceAtLeast(10f).sp, color = Color.Gray)
        }
    }
}

@Composable
fun Lines(series: List<Pair<Color, List<Float>>>, lo: Float, hi: Float, marks: List<Float> = emptyList(), h: Dp = 140.dp, fill: Boolean = false) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(h).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF))) {
        for (i in 1..3) drawLine(grid, Offset(0f, size.height * i / 4), Offset(size.width, size.height * i / 4))
        marks.forEach { m ->
            val y = size.height * (1 - (m - lo) / (hi - lo))
            drawLine(Bad.copy(alpha = 0.8f), Offset(0f, y), Offset(size.width, y), strokeWidth = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f)))
        }
        series.forEach { (c, v) ->
            if (v.size < 2) return@forEach
            val path = Path(); var pen = false; var gaps = false
            v.forEachIndexed { i, x ->
                if (x.isNaN()) { pen = false; gaps = true } else {
                    val px = size.width * i / (v.size - 1); val py = size.height * (1 - ((x - lo) / (hi - lo)).coerceIn(0f, 1f))
                    if (!pen) { path.moveTo(px, py); pen = true } else path.lineTo(px, py)
                }
            }
            if (fill && !gaps) {
                val fp = Path(); fp.addPath(path); fp.lineTo(size.width, size.height); fp.lineTo(0f, size.height); fp.close()
                drawPath(fp, Brush.verticalGradient(listOf(c.copy(alpha = 0.30f), Color.Transparent)))
            }
            drawPath(path, c, style = Stroke(4f, cap = StrokeCap.Round))
        }
    }
}

@Composable
fun LiveChart(vm: ObdVm) {
    var sel by remember { mutableIntStateOf(IDX["rpm"]!!) }
    val rows = remember(vm.tick) { vm.recent(200) }
    val avail = PIDS.indices.filter { i -> rows.any { !it.v[i].isNaN() } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        avail.forEach { i -> FilterChip(selected = sel == i, onClick = { sel = i }, label = { Text(PIDS[i].name) }) }
    }
    val vals = rows.map { it.v[sel].toFloat() }; val clean = vals.filter { !it.isNaN() }
    val lo = minOf(clean.minOrNull() ?: 0f, 0f); val hi = maxOf(clean.maxOrNull() ?: 1f, lo + 1f) * 1.1f
    Lines(listOf(Accent to vals), lo, hi, fill = true)
    Text("آخرین: %.1f   حداکثر: %.1f %s".format(clean.lastOrNull() ?: 0f, clean.maxOrNull() ?: 0f, PIDS[sel].unit), fontSize = 12.sp)
}

@Composable
fun Info(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
    Text(k, Modifier.weight(1f)); Text(v, fontWeight = FontWeight.Bold)
}

@Composable
fun ParamBar(p: P, v: Double) {
    val lo = lowOf(p)
    val frac = ((v.toFloat() - lo) / (p.max - lo)).coerceIn(0f, 1f)
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(p.name, fontSize = 13.sp); Text("%.1f %s".format(v, p.unit), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Track)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(Brush.horizontalGradient(listOf(Cyan, Accent))))
        }
    }
}

@Composable
fun HealthCard(vm: ObdVm) {
    val l = vm.live; val cm = num(vm.coolMax) ?: 105.0
    var score = 100; val notes = mutableListOf<String>()
    val cl = l["cool"]
    if (cl != null) {
        if (cl > cm) { score -= 30; notes += "دمای موتور بالاست" } else if (cl > cm - 8) { score -= 8 }
    }
    val vt = l["volt"]
    if (vt != null && (l["rpm"] ?: 0.0) > 500 && vt < 12.5) { score -= 20; notes += "ولتاژ شارژ پایین" }
    if (vm.thrState == 2) { score -= 35; notes += "ناهمخوانی دریچه گاز" } else if (vm.thrState == 1) { score -= 8 }
    vm.dtcs?.let { if (it.isNotEmpty()) { score -= minOf(30, it.size * 10); notes += "${it.size} کد خطا" } }
    if (!vm.connected) { notes.clear(); notes += "برای ارزیابی وصل شوید" }
    score = score.coerceIn(0, 100)
    val col = if (!vm.connected) Color.Gray else if (score >= 80) Ok else if (score >= 55) Warn else Bad
    val sweep by animateFloatAsState(if (vm.connected) score / 100f else 0f, tween(500), label = "h")
    GCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                    val st = Stroke(14f, cap = StrokeCap.Round)
                    drawArc(Track, -90f, 360f, false, style = st); drawArc(col, -90f, 360f * sweep, false, style = st)
                }
                Text(if (vm.connected) "$score" else "—", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = col)
            }
            Spacer(Modifier.width(14.dp))
            Column { Text("سلامت کلی خودرو", fontWeight = FontWeight.Bold); Text(if (notes.isEmpty()) "همه‌چیز عادی است ✅" else notes.joinToString(" • "), fontSize = 13.sp) }
        }
    }
}

@Composable
fun GraphicDash(vm: ObdVm, onStandby: () -> Unit) {
    val land = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val l = vm.live
    val rm = num(vm.rpmMax) ?: 6000.0; val cm = num(vm.coolMax) ?: 105.0
    HealthCard(vm)
    vm.alerts.forEach { GCard(Color(0xFFB71C1C)) { Text(it, color = Color.White, fontWeight = FontWeight.Bold) } }
    if (vm.thrState == 2) GCard(Color(0xFFB71C1C)) { Text("🦶 ناهمخوانی دریچه گاز (اختلاف A/B: ${vm.thrDiff?.let { "%.0f%%".format(it) } ?: "—"}) — جزئیات: بیشتر ▸ دریچه گاز", color = Color.White, fontWeight = FontWeight.Bold) }
    vm.newEv?.let { GCard(Color(0xFFE65100)) { Text("📝 تحلیل رویداد آماده است (تب «ضبط»): $it", color = Color.White) } }
    val rpm: @Composable (Modifier) -> Unit = { m -> Gauge(l["rpm"], 8000f, "دور موتور", "rpm", m, Accent, (l["rpm"] ?: 0.0) > rm) }
    val spd: @Composable (Modifier) -> Unit = { m -> Gauge(l["spd"], 220f, "سرعت", "km/h", m, Cyan) }
    val cool: @Composable (Modifier) -> Unit = { m -> Gauge(l["cool"], 130f, "دمای آب", "°C", m, Ok, (l["cool"] ?: 0.0) > cm) }
    val load: @Composable (Modifier) -> Unit = { m -> Gauge(l["load"], 100f, "بار موتور", "%", m, Warn) }
    if (land) Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); rpm(m); spd(m); cool(m); load(m) }
    else {
        Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); rpm(m); spd(m) }
        Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); cool(m); load(m) }
    }
    val f = vm.lph; val v = l["spd"]
    GCard { Info("مصرف لحظه‌ای", when { f == null -> "—"; v != null && v > 3 -> "%.1f L/100km".format(f / v * 100); else -> "%.1f L/h".format(f) }) }
    GCard {
        PIDS.forEachIndexed { i, p -> val x = l.v[i]; if (!x.isNaN() && p.key in DASH_KEYS) ParamBar(p, x) }
        if (!vm.connected) Text("ابتدا در تب «اتصال» وصل شوید.")
    }
    GCard { Text("نمودار زنده", style = MaterialTheme.typography.titleMedium); LiveChart(vm) }
    OutlinedButton(onStandby, Modifier.fillMaxWidth()) { Text("🌙 حالت استند بای (صفحه کم‌نور، قابل نمایش روی قفل‌صفحه)") }
}

@Composable
fun LinkBar(vm: ObdVm) {
    val alive = vm.connected && vm.live.t > 0 && System.currentTimeMillis() - vm.live.t < 6000 && vm.live.v.any { !it.isNaN() }
    fun c(ok: Boolean, warn: Boolean = false) = if (ok) Ok else if (warn) Warn else Color.Gray
    @Composable fun Node(icon: String, label: String, col: Color) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(col.copy(alpha = 0.2f)).border(2.dp, col, CircleShape), contentAlignment = Alignment.Center) { Text(icon, fontSize = 20.sp) }
        Text(label, fontSize = 11.sp, color = col)
    }
    GCard {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Node("📱", "APP", Ok)
            Box(Modifier.weight(1f).height(3.dp).background(c(vm.connected)))
            Node("🔌", "OBD2", c(vm.connected))
            Box(Modifier.weight(1f).height(3.dp).background(c(alive)))
            Node("🚗", "ECU", c(alive, vm.connected))
        }
    }
}

@Composable
fun DashHost(vm: ObdVm, onStandby: () -> Unit) {
    var sub by remember { mutableIntStateOf(0) }
    LinkBar(vm)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("نمای گرافیکی", "مانیتورینگ", "نمودار فردی", "نمودار یکپارچه").forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(n) }) }
    }
    when (sub) { 0 -> GraphicDash(vm, onStandby); 1 -> MonitorTab(vm) { sub = 2 }; 2 -> SingleChart(vm); else -> MultiChart(vm) }
}

@Composable
fun MonitorTab(vm: ObdVm, onPick: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val l = vm.live; val t = vm.texts
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("جستجو") }, singleLine = true, shape = RoundedCornerShape(14.dp))
    Text("داده‌های استاندارد OBD-II", style = MaterialTheme.typography.titleMedium)
    Text("پارامتری که خودرو پشتیبانی نکند N/A می‌ماند. روی هر پارامتر عددی بزنید تا نمودارش باز شود.", fontSize = 12.sp)
    @Composable fun Item(name: String, value: String?, onClick: (() -> Unit)?) {
        Card(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier), RoundedCornerShape(14.dp), CardDefaults.cardColors(containerColor = CardBg)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (value != null) Ok else Color.Gray))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(name, fontSize = 13.sp)
                    Text(value ?: "N/A", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (value != null) Color.Unspecified else Color.Gray)
                }
            }
        }
    }
    TXT.filter { q.isBlank() || it.name.contains(q) || it.key.contains(q, true) }.forEach { Item(it.name, t[it.key], null) }
    PIDS.forEachIndexed { i, p ->
        if (q.isBlank() || p.name.contains(q) || p.key.contains(q, true)) {
            val x = l.v[i]
            Item(p.name, if (x.isNaN()) null else "%.1f %s".format(x, p.unit).trim()) { vm.singleSel = i; onPick() }
        }
    }
}

@Composable
fun SingleChart(vm: ObdVm) {
    var win by remember { mutableIntStateOf(1) }
    val secs = listOf(30, 120, 900)[win]
    val rows = remember(vm.tick, win) { val t0 = System.currentTimeMillis() - secs * 1000L; vm.recent(3000).filter { it.t >= t0 } }
    val avail = PIDS.indices.filter { i -> rows.any { !it.v[i].isNaN() } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("۳۰ ثانیه", "۲ دقیقه", "۱۵ دقیقه").forEachIndexed { i, n -> FilterChip(selected = win == i, onClick = { win = i }, label = { Text(n) }) }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        avail.forEach { i -> FilterChip(selected = vm.singleSel == i, onClick = { vm.singleSel = i }, label = { Text(PIDS[i].name) }) }
    }
    val sel = vm.singleSel
    val vals = rows.map { it.v[sel].toFloat() }; val clean = vals.filter { !it.isNaN() }
    val lo = minOf(clean.minOrNull() ?: 0f, 0f); val hi = maxOf(clean.maxOrNull() ?: 1f, lo + 1f) * 1.1f
    GCard {
        Text(PIDS[sel].name + (if (PIDS[sel].unit.isEmpty()) "" else " (${PIDS[sel].unit})"), fontWeight = FontWeight.Bold)
        if (clean.isEmpty()) Text("برای این پارامتر داده‌ای نیست (N/A یا هنوز وصل نشده‌اید).", fontSize = 13.sp)
        Lines(listOf(Accent to thin(vals)), lo, hi, h = 220.dp, fill = true)
        if (clean.isNotEmpty()) {
            Info("اکنون", "%.2f".format(clean.last())); Info("کمترین", "%.2f".format(clean.min()))
            Info("میانگین", "%.2f".format(clean.average())); Info("بیشترین", "%.2f".format(clean.max()))
        }
    }
}

@Composable
fun MultiChart(vm: ObdVm) {
    val colors = listOf(Accent, Cyan, Ok, Warn, Color(0xFFAB47BC), Bad)
    val rows = remember(vm.tick) { vm.recent(400) }
    val avail = PIDS.indices.filter { i -> rows.any { !it.v[i].isNaN() } }
    Text("تا ۶ پارامتر انتخاب کنید؛ هر کدام روی مقیاس خودش (۰ تا ۱۰۰٪ بازه‌ی معمول) نمایش داده می‌شود.", fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        avail.forEach { i ->
            FilterChip(selected = i in vm.multiSel, onClick = { if (i in vm.multiSel) vm.multiSel.remove(i) else if (vm.multiSel.size < 6) vm.multiSel.add(i) }, label = { Text(PIDS[i].name) })
        }
    }
    val sel = vm.multiSel.toList()
    GCard {
        Lines(sel.mapIndexed { k, i ->
            val p = PIDS[i]; val lo = lowOf(p)
            colors[k % colors.size] to thin(rows.map { r -> val x = r.v[i]; if (x.isNaN()) Float.NaN else ((x.toFloat() - lo) / (p.max - lo) * 100f) })
        }, 0f, 100f, h = 220.dp)
        sel.forEachIndexed { k, i ->
            val x = vm.live.v[i]
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(colors[k % colors.size])); Spacer(Modifier.width(8.dp))
                Text(PIDS[i].name, Modifier.weight(1f), fontSize = 13.sp)
                Text(if (x.isNaN()) "N/A" else "%.1f %s".format(x, PIDS[i].unit), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun DtcTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val en = vm.connected && !vm.busy
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ vm.readDtc(3) }, enabled = en) { Text("ذخیره‌شده") }
        Button({ vm.readDtc(7) }, enabled = en) { Text("در انتظار") }
        Button({ vm.readDtc(0x0A) }, enabled = en) { Text("دائمی") }
        Button({ vm.readFreeze() }, enabled = en) { Text("Freeze Frame") }
        OutlinedButton({ vm.clearDtc() }, enabled = en) { Text("پاک کردن") }
    }
    Text("توجه: پاک کردن کدها چراغ چک را خاموش می‌کند ولی مشکل را رفع نمی‌کند (و Freeze Frame هم پاک می‌شود).", fontSize = 12.sp)
    val d = vm.dtcs
    if (d != null) Text(when (vm.dtcMode) { 3 -> "خطاهای ذخیره‌شده"; 7 -> "خطاهای در انتظار (Pending)"; else -> "خطاهای دائمی" }, style = MaterialTheme.typography.titleMedium)
    if (d != null && d.isEmpty()) Text("هیچ خطایی ثبت نشده ✅")
    d?.forEach { code ->
        GCard {
            Text(code, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Accent)
            Text(dtcDesc(code))
            TextButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$code+OBD"))) }) { Text("جست‌وجو در اینترنت") }
        }
    }
    vm.freeze?.let { fz ->
        GCard {
            Text("🧊 Freeze Frame" + (vm.freezeCode?.let { " — $it" } ?: ""), style = MaterialTheme.typography.titleMedium)
            if (fz.isEmpty()) Text("ECU فریم ثبت‌شده‌ای ندارد (خطای ذخیره‌شده‌ای نیست یا پشتیبانی نمی‌کند).")
            PIDS.forEach { p -> fz[p.key]?.let { ParamBar(p, it) } }
        }
    }
}

@Composable
fun RecTab(vm: ObdVm) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.newEv = null }
    GCard {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("ضبط خودکار همه‌ی پارامترها", fontWeight = FontWeight.Bold); Switch(vm.recOn, { vm.setRec(it) })
        }
        Text(if (vm.connected && vm.recOn) "🔴 در حال ضبط: ${vm.recFile} (${vm.recRows} ردیف)" else "ضبط فعال نیست", fontSize = 12.sp)
    }
    Button({ vm.manualEvent() }, Modifier.fillMaxWidth(), enabled = vm.connected) { Text("📝 ثبت لحظه‌ی مشکل (تحلیل ۶۰ ثانیه قبل و ۱۵ ثانیه بعد)") }
    Text("رویدادها و گزارش‌ها", style = MaterialTheme.typography.titleMedium)
    if (vm.events.isEmpty()) Text("هنوز رویدادی ثبت نشده. هر خطای جدید که رخ دهد، پارامترهای ثابت/متغیر قبل از آن و دلیل احتمالی این‌جا ذخیره می‌شود.", fontSize = 13.sp)
    vm.events.forEach { e ->
        var open by remember(e.file.name) { mutableStateOf(false) }
        GCard {
            Text(e.title, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { open = !open })
            if (open) {
                Text(e.text, fontSize = 13.sp)
                Row { TextButton({ shareText(ctx, e.title + "\n" + e.text) }) { Text("اشتراک‌گذاری") }; TextButton({ vm.deleteEvent(e) }) { Text("حذف") } }
            } else Text("برای دیدن تحلیل بزنید", fontSize = 12.sp)
        }
    }
    Text("فایل‌های ضبط (CSV)", style = MaterialTheme.typography.titleMedium)
    vm.logs.forEach { f ->
        GCard {
            Text(f.name); Text("%.0f KB".format(f.length() / 1024.0), fontSize = 12.sp)
            Row { TextButton({ shareFile(ctx, f) }) { Text("اشتراک‌گذاری") }; TextButton({ vm.deleteLog(f) }) { Text("حذف") } }
        }
    }
}

@Composable
fun MoreTab(vm: ObdVm) {
    var sub by remember { mutableIntStateOf(0) }
    val names = listOf("دریچه گاز برقی", "اطلاعات خودرو", "تست‌ها", "سفر و مصرف", "تنظیمات")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        names.forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(n) }) }
    }
    when (sub) { 0 -> ThrottleTab(vm); 1 -> InfoTab(vm); 2 -> TestTab(vm); 3 -> TripTab(vm); else -> SettingsTab(vm) }
}

@Composable
fun ThrottleTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val l = vm.live
    val rows = remember(vm.tick) { vm.recent(200) }
    Text("🦶 عیب‌یابی دریچه‌ی گاز برقی", style = MaterialTheme.typography.titleMedium)
    Text("برای خطاهایی مثل «تفاوت موقعیت دریچه گاز» (P2135 و مشابه): حین رانندگی دکمه‌ی شروع را بزنید، چند بار آهسته و تند گاز بدهید و در پایان گزارش را ببینید. حتی بدون زدن دکمه، اگر اختلاف بیش از حد باشد، رویداد خودکار ثبت می‌شود.", fontSize = 13.sp)
    Row(Modifier.fillMaxWidth()) {
        val m = Modifier.weight(1f)
        Gauge(l["tps"], 100f, "TPS A", "%", m, Accent, ts = 18); Gauge(l["tpsb"], 100f, "TPS B", "%", m, Cyan, ts = 18)
        Gauge(l["ped"], 100f, "پدال", "%", m, Ok, ts = 18); Gauge(l["tcmd"], 100f, "فرمان ECU", "%", m, Warn, ts = 18)
    }
    val st = vm.thrState
    GCard(when (st) { 2 -> Color(0xFF7F1D1D); 1 -> Color(0xFF6B4E00); else -> CardBg }) {
        Text(when { !vm.connected -> "متصل نیستید"; st == 2 -> "🔴 ناهمخوانی دریچه/پدال!"; st == 1 -> "⚠️ اختلاف کم"; vm.thrDiff == null && vm.thrDiffPed == null -> "ℹ️ ECU دریچه‌ی دوم/پدال را از OBD2 نمی‌دهد؛ بررسی با TPS A، بار و MAP انجام می‌شود"; else -> "✅ هماهنگ" }, fontWeight = FontWeight.Bold)
        Info("اختلاف TPS A/B", vm.thrDiff?.let { "%.1f%%".format(it) } ?: "—")
        Info("اختلاف پدال D/E", vm.thrDiffPed?.let { "%.1f%%".format(it) } ?: "—")
    }
    GCard {
        Text("TPS A (نارنجی) و TPS B (فیروزه‌ای) و پدال (سبز)", fontSize = 12.sp)
        Lines(listOf(Accent to rows.map { it["tps"]?.toFloat() ?: Float.NaN }, Cyan to rows.map { it["tpsb"]?.toFloat() ?: Float.NaN }, Ok to rows.map { it["ped"]?.toFloat() ?: Float.NaN }), 0f, 100f)
        Text("اختلاف A/B (خط‌چین قرمز = حد ۶٪)", fontSize = 12.sp)
        Lines(listOf(Bad to rows.map { r -> val a = r["tps"]; val b = r["tpsb"]; if (a != null && b != null) kotlin.math.abs(a - b).toFloat() else Float.NaN }), 0f, 20f, listOf(6f), 90.dp)
    }
    if (!vm.thrOn) Button({ vm.thrStart() }, Modifier.fillMaxWidth(), enabled = vm.connected) { Text("▶ شروع ثبت گزارش (حین رانندگی)") }
    else Button({ vm.thrStop() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Bad)) { Text("⏹ پایان و نمایش گزارش (در حال ثبت…)") }
    vm.thrReport?.let { rep ->
        GCard(when (rep.level) { 2 -> Color(0xFF3B1212); 1 -> Color(0xFF3A2E08); else -> Color(0xFF12301A) }) {
            Text(rep.verdict, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            rep.lines.forEach { (k, v) -> Info(k, v) }
            Text("🔎 دلیل(های) احتمالی", fontWeight = FontWeight.Bold)
            rep.causes.forEachIndexed { i, s -> Text("${i + 1}) $s", fontSize = 13.sp) }
            TextButton({ shareText(ctx, "گزارش دریچه گاز\n" + rep.text()) }) { Text("اشتراک‌گذاری گزارش") }
        }
        Text("گزارش در تب «ضبط» هم ذخیره شد. این تحلیل بر پایه‌ی قاعده است و قطعی نیست.", fontSize = 12.sp)
    }
}

@Composable
fun InfoTab(vm: ObdVm) {
    Button({ vm.loadInfo() }, Modifier.fillMaxWidth(), enabled = vm.connected && !vm.busy) { Text("خواندن اطلاعات خودرو") }
    GCard { vm.info.forEach { (k, v) -> Info(k, v) } }
    Text("کیلومتر واقعی (کارکرد)، تست عملگرها و ECUهای دیگر (ABS، ایربگ، گیربکس، ایموبیلایزر) به پروتکل اختصاصی هر خودرو و دانگل مخصوص نیاز دارند و با OBD2 استاندارد ممکن نیستند.", fontSize = 12.sp)
}

@Composable
fun TestTab(vm: ObdVm) {
    Text("🔋 تست باتری و دینام", style = MaterialTheme.typography.titleMedium)
    Text("۱) سوئیچ را باز کنید (موتور خاموش) و چند ثانیه صبر کنید.\n۲) موتور را روشن کنید.\n۳) ۱۵ ثانیه بعد دور را حدود ۲۵۰۰ ببرید و ۱۰ ثانیه نگه دارید.\nنتیجه از ۳ دقیقه‌ی اخیر ضبط محاسبه می‌شود.", fontSize = 13.sp)
    val rows = remember(vm.tick) { vm.recent(700).filter { it.t >= System.currentTimeMillis() - 180_000 } }
    GCard {
        Info("ولتاژ لحظه‌ای", vm.live["volt"]?.let { "%.2f V".format(it) } ?: "—")
        batteryReport(rows).forEach { (k, v) -> Info(k, v) }
    }
    Text("〰️ تست پایداری دور آرام (لرزش موتور)", style = MaterialTheme.typography.titleMedium)
    Text("خودرو را در توقف و دنده‌ی خلاص، موتور گرم، بدون فشردن پدال نگه دارید و دکمه را بزنید.", fontSize = 13.sp)
    var t0 by remember { mutableStateOf<Long?>(null) }
    var res by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    LaunchedEffect(t0) { val s = t0 ?: return@LaunchedEffect; delay(20_000); res = idleReport(vm.recent(2000).filter { it.t >= s }); t0 = null }
    Button({ res = null; t0 = System.currentTimeMillis() }, Modifier.fillMaxWidth(), enabled = vm.connected && t0 == null) { Text(if (t0 != null) "در حال اندازه‌گیری… (۲۰ ثانیه)" else "شروع تست ۲۰ ثانیه‌ای") }
    res?.let { r -> GCard { r.forEach { (k, v) -> Info(k, v) } } }
}

@Composable
fun TripTab(vm: ObdVm) {
    Button({ if (vm.tripOn) vm.stopTrip() else vm.startTrip() }, Modifier.fillMaxWidth(), enabled = vm.connected) {
        Text(if (vm.tripOn) "پایان و ذخیره سفر" else "شروع سفر جدید")
    }
    if (vm.tripOn) GCard {
        Info("مسافت", "%.2f km".format(vm.tKm)); Info("سوخت مصرفی", "%.2f L".format(vm.tL))
        Info("میانگین مصرف", if (vm.tKm > 0.1) "%.1f L/100km".format(vm.tL / vm.tKm * 100) else "—")
        Info("حداکثر سرعت", "%.0f km/h".format(vm.tMax))
        LiveChart(vm)
    }
    Text("سابقه سفرها", style = MaterialTheme.typography.titleMedium)
    vm.trips.forEach { t ->
        GCard {
            Text(fa(t.t), fontWeight = FontWeight.Bold)
            Text("%.1f km • %.1f L • %.1f L/100km • حداکثر %.0f km/h".format(t.km, t.l, if (t.km > 0) t.l / t.km * 100 else 0.0, t.max))
        }
    }
}

@Composable
fun SettingsTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val dec = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Text("موتور و هشدارها", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(vm.disp, { vm.disp = it; vm.save() }, label = { Text("حجم موتور (لیتر)") }, keyboardOptions = dec, singleLine = true)
    OutlinedTextField(vm.coolMax, { vm.coolMax = it; vm.save() }, label = { Text("هشدار دمای موتور (°C)") }, keyboardOptions = dec, singleLine = true)
    OutlinedTextField(vm.rpmMax, { vm.rpmMax = it; vm.save() }, label = { Text("هشدار دور موتور (rpm)") }, keyboardOptions = dec, singleLine = true)
    GCard {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("پایش کامل همه‌ی پارامترها", fontWeight = FontWeight.Bold); Switch(vm.fullPoll, { vm.setFull(it) }) }
        Text("خاموش: پارامترهای اصلی سریع و بقیه هر چند ثانیه یک‌بار خوانده می‌شوند. روشن: همه‌ی پارامترهای پشتیبانی‌شده در هر چرخه خوانده می‌شوند (دقیق‌تر ولی کندتر؛ مناسب تشخیص ثابت‌ایستاده). بعد از تغییر، دوباره وصل شوید.", fontSize = 12.sp)
    }
    HorizontalDivider()
    Text("فعال ماندن در پس‌زمینه و استند بای", style = MaterialTheme.typography.titleMedium)
    Text("با خاموش‌شدن صفحه، مقادیر زنده در اعلان دائمی به‌روز می‌شوند و هشدارها با لرزش و صدا می‌آیند. برای اینکه اندروید برنامه را وسط مسیر نبندد، دکمه‌ی زیر را بزنید و برای Baloch OBD «بدون محدودیت / Don't optimize» را انتخاب کنید. در شیائومی، سامسونگ و آنر «اجرای خودکار / Autostart» را هم روشن کنید.", fontSize = 13.sp)
    OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("تنظیمات بهینه‌سازی باتری") }
    HorizontalDivider()
    Text("کالیبراسیون مصرف سوخت", style = MaterialTheme.typography.titleMedium)
    Text("۱) باک را کامل پر کنید و «شروع شمارش» را بزنید.\n۲) رانندگی کنید (اپ وصل باشد).\n۳) دفعه بعد که باک را کامل پر کردید، لیتر واقعی را وارد و «اعمال» را بزنید.", fontSize = 13.sp)
    GCard { Info("تخمین اپ از شروع شمارش", "%.1f L".format(vm.calEst)); Info("ضریب فعلی", "%.2f".format(vm.calib)) }
    var actual by remember { mutableStateOf("") }
    OutlinedTextField(actual, { actual = it }, label = { Text("لیتر واقعیِ بنزین‌زده‌شده") }, keyboardOptions = dec, singleLine = true)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton({ vm.resetCal() }) { Text("شروع شمارش") }
        Button({ vm.applyCal(num(actual) ?: 0.0) }) { Text("اعمال") }
    }
}
