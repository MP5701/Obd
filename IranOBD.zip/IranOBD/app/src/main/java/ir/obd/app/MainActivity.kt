@file:OptIn(ExperimentalMaterial3Api::class)

package ir.obd.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.delay
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

/** تبدیل ارقام فارسی/عربی و جداکننده‌ها به عدد */
fun num(s: String): Double? = s.map {
    when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); '٫', '،', ',' -> '.'; else -> it }
}.joinToString("").toDoubleOrNull()

fun fa(t: Long): String = android.icu.text.SimpleDateFormat("yyyy/MM/dd HH:mm", android.icu.util.ULocale("fa_IR@calendar=persian")).format(java.util.Date(t))

fun shareText(ctx: Context, s: String) = ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s) }, null))
fun shareFile(ctx: Context, f: File) {
    val u = FileProvider.getUriForFile(ctx, "ir.baloch.obd.files", f)
    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/csv"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, null))
}

@Composable
fun App(vm: ObdVm = obdVm(LocalContext.current)) {
    var tab by remember { mutableIntStateOf(0) }
    val names = listOf("اتصال", "داشبورد", "خطاها", "ضبط", "بیشتر"); val icons = listOf("🔌", "📊", "⚠️", "🔴", "☰")
    Scaffold(bottomBar = {
        NavigationBar { names.forEachIndexed { i, n -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icons[i]) }, label = { Text(n, fontSize = 11.sp) }) } }
    }) { p ->
        Column(Modifier.padding(p).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (tab) { 0 -> ConnectTab(vm); 1 -> DashTab(vm); 2 -> DtcTab(vm); 3 -> RecTab(vm); else -> MoreTab(vm) }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ConnectTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val ad = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter }
    var devices by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    fun refresh() { devices = try { ad?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    LaunchedEffect(Unit) {
        val ps = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) ps += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) ps += Manifest.permission.POST_NOTIFICATIONS
        if (ps.isEmpty()) refresh() else perm.launch(ps.toTypedArray())
    }
    Text("Baloch OBD", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF9800))
    Text(vm.status, style = MaterialTheme.typography.titleMedium)
    Text("دانگل ELM327 را از تنظیمات بلوتوث گوشی جفت کنید (رمز: 1234 یا 0000)، سوئیچ را باز کنید و دستگاه را انتخاب کنید. بعد از اتصال، ضبط و پایش حتی با خاموش‌شدن صفحه یا رفتن به برنامه‌ی دیگر ادامه دارد.", fontSize = 13.sp)
    Text("پروتکل (برای خودروهای قدیمی‌تر ممکن است لازم باشد دستی انتخاب شود):")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("0" to "خودکار", "3" to "ISO 9141", "4" to "KWP آهسته", "5" to "KWP سریع", "6" to "CAN")
            .forEach { (k, n) -> FilterChip(selected = vm.proto == k, onClick = { vm.proto = k; vm.save() }, label = { Text(n) }) }
    }
    if (vm.connected) OutlinedButton({ vm.disconnect() }, Modifier.fillMaxWidth()) { Text("قطع اتصال و پایان ضبط") }
    if (devices.isEmpty()) Text("هیچ دستگاه جفت‌شده‌ای پیدا نشد.")
    devices.forEach { d -> Button({ vm.connect(d) }, Modifier.fillMaxWidth()) { Text(d.name ?: d.address) } }
}

@Composable
fun Gauge(value: Double?, max: Float, label: String, unit: String, modifier: Modifier = Modifier, danger: Boolean = false) {
    val color = if (danger) Color(0xFFE53935) else MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val frac = ((value ?: 0.0).toFloat() / max).coerceIn(0f, 1f)
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            val st = Stroke(24f, cap = StrokeCap.Round); val o = Offset(12f, 12f); val sz = Size(size.width - 24f, size.height - 24f)
            drawArc(track, 135f, 270f, false, o, sz, style = st)
            drawArc(color, 135f, 270f * frac, false, o, sz, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.0f".format(it) } ?: "—", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = if (danger) color else Color.Unspecified)
            Text("$label $unit", fontSize = 12.sp)
        }
    }
}

@Composable
fun LiveChart(vm: ObdVm) {
    var sel by remember { mutableIntStateOf(IDX["rpm"]!!) }
    val rows = remember(vm.tick) { vm.recent(200) }
    val avail = PIDS.indices.filter { i -> rows.any { !it.v[i].isNaN() } }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        avail.forEach { i -> FilterChip(selected = sel == i, onClick = { sel = i }, label = { Text(PIDS[i].name) }) }
    }
    val vals = rows.map { it.v[sel] }.filter { !it.isNaN() }.map { it.toFloat() }
    val color = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val lo = minOf(vals.minOrNull() ?: 0f, 0f); val hi = maxOf(vals.maxOrNull() ?: 1f, lo + 1f)
        val mx = hi + (hi - lo) * 0.1f
        for (i in 1..3) drawLine(grid, Offset(0f, size.height * i / 4), Offset(size.width, size.height * i / 4))
        if (vals.size > 1) {
            val path = Path()
            vals.forEachIndexed { i, v ->
                val x = size.width * i / (vals.size - 1); val y = size.height * (1 - (v - lo) / (mx - lo))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(4f))
        }
    }
    Text("آخرین: %.1f   حداکثر: %.1f %s".format(vals.lastOrNull() ?: 0f, vals.maxOrNull() ?: 0f, PIDS[sel].unit), fontSize = 12.sp)
}

@Composable
fun Info(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
    Text(k, Modifier.weight(1f)); Text(v, fontWeight = FontWeight.Bold)
}

@Composable
fun DashTab(vm: ObdVm) {
    val land = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val l = vm.live
    val rm = num(vm.rpmMax) ?: 6000.0; val cm = num(vm.coolMax) ?: 105.0
    vm.alerts.forEach {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFB71C1C))) {
            Text(it, Modifier.padding(12.dp), color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
    vm.newEv?.let {
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE65100))) {
            Text("📝 تحلیل رویداد آماده است (تب «ضبط»): $it", Modifier.padding(12.dp), color = Color.White)
        }
    }
    if (!vm.connected) Text("ابتدا در تب «اتصال» وصل شوید.")
    val rpm: @Composable (Modifier) -> Unit = { m -> Gauge(l["rpm"], 8000f, "دور موتور", "rpm", m, (l["rpm"] ?: 0.0) > rm) }
    val spd: @Composable (Modifier) -> Unit = { m -> Gauge(l["spd"], 220f, "سرعت", "km/h", m) }
    val cool: @Composable (Modifier) -> Unit = { m -> Gauge(l["cool"], 130f, "دمای آب", "°C", m, (l["cool"] ?: 0.0) > cm) }
    val load: @Composable (Modifier) -> Unit = { m -> Gauge(l["load"], 100f, "بار موتور", "%", m) }
    if (land) Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); rpm(m); spd(m); cool(m); load(m) }
    else {
        Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); rpm(m); spd(m) }
        Row(Modifier.fillMaxWidth()) { val m = Modifier.weight(1f); cool(m); load(m) }
    }
    val f = vm.lph; val v = l["spd"]
    Info("مصرف لحظه‌ای", when { f == null -> "—"; v != null && v > 3 -> "%.1f L/100km".format(f / v * 100); else -> "%.1f L/h".format(f) })
    PIDS.forEachIndexed { i, p ->
        val x = l.v[i]
        if (!x.isNaN() && p.key !in setOf("rpm", "spd", "cool", "load")) Info(p.name, "%.1f %s".format(x, p.unit))
    }
    Text("نمودار زنده", style = MaterialTheme.typography.titleMedium)
    LiveChart(vm)
}

@Composable
fun DtcTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val en = vm.connected && !vm.busy
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ vm.readDtc(3) }, enabled = en) { Text("ذخیره‌شده") }
        Button({ vm.readDtc(7) }, enabled = en) { Text("در انتظار") }
        Button({ vm.readDtc(0x0A) }, enabled = en) { Text("دائمی") }
        Button({ vm.readFreeze() }, enabled = en) { Text("Freeze Frame") }
        OutlinedButton({ vm.clearDtc() }, enabled = en) { Text("پاک کردن") }
    }
    Text("توجه: پاک کردن کدها چراغ چک را خاموش می‌کند ولی مشکل را رفع نمی‌کند (و Freeze Frame هم پاک می‌شود).", fontSize = 12.sp)
    val d = vm.dtcs
    if (d != null) Text(when (vm.dtcMode) { 3 -> "خطاهای ذخیره‌شده"; 7 -> "خطاهای در انتظار (Pending)"; else -> "خطاهای دائمی" }, style = MaterialTheme.typography.titleMedium)
    if (d != null && d.isEmpty()) Text("هیچ خطایی ثبت نشده ✅")
    d?.forEach { code ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(dtcDesc(code))
            TextButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$code+OBD"))) }) { Text("جست‌وجو در اینترنت") }
        } }
    }
    vm.freeze?.let { fz ->
        Text("🧊 Freeze Frame" + (vm.freezeCode?.let { " — $it" } ?: ""), style = MaterialTheme.typography.titleMedium)
        if (fz.isEmpty()) Text("ECU فریم ثبت‌شده‌ای ندارد (خطای ذخیره‌شده‌ای نیست یا پشتیبانی نمی‌کند).")
        PIDS.forEach { p -> fz[p.key]?.let { Info(p.name, "%.1f %s".format(it, p.unit)) } }
    }
}

@Composable
fun RecTab(vm: ObdVm) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.newEv = null }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("ضبط خودکار همه‌ی پارامترها", fontWeight = FontWeight.Bold); Switch(vm.recOn, { vm.setRec(it) })
        }
        Text(if (vm.connected && vm.recOn) "🔴 در حال ضبط: ${vm.recFile} (${vm.recRows} ردیف)" else "ضبط فعال نیست", fontSize = 12.sp)
    } }
    Button({ vm.manualEvent() }, Modifier.fillMaxWidth(), enabled = vm.connected) { Text("📝 ثبت لحظه‌ی مشکل (تحلیل ۶۰ ثانیه قبل و ۱۵ ثانیه بعد)") }
    Text("رویدادهای خطا", style = MaterialTheme.typography.titleMedium)
    if (vm.events.isEmpty()) Text("هنوز رویدادی ثبت نشده. هر خطای جدید که رخ دهد، پارامترهای ثابت/متغیر قبل از آن و دلیل احتمالی این‌جا ذخیره می‌شود.", fontSize = 13.sp)
    vm.events.forEach { e ->
        var open by remember(e.file.name) { mutableStateOf(false) }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(e.title, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { open = !open })
            if (open) {
                Text(e.text, fontSize = 13.sp)
                Row { TextButton({ shareText(ctx, e.title + "\n" + e.text) }) { Text("اشتراک‌گذاری") }; TextButton({ vm.deleteEvent(e) }) { Text("حذف") } }
            } else Text("برای دیدن تحلیل بزنید", fontSize = 12.sp)
        } }
    }
    Text("فایل‌های ضبط (CSV)", style = MaterialTheme.typography.titleMedium)
    vm.logs.forEach { f ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(f.name); Text("%.0f KB".format(f.length() / 1024.0), fontSize = 12.sp)
            Row { TextButton({ shareFile(ctx, f) }) { Text("اشتراک‌گذاری") }; TextButton({ vm.deleteLog(f) }) { Text("حذف") } }
        } }
    }
}

@Composable
fun MoreTab(vm: ObdVm) {
    var sub by remember { mutableIntStateOf(0) }
    val names = listOf("اطلاعات خودرو", "تست‌ها", "سفر و مصرف", "تنظیمات")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        names.forEachIndexed { i, n -> FilterChip(selected = sub == i, onClick = { sub = i }, label = { Text(n) }) }
    }
    when (sub) { 0 -> InfoTab(vm); 1 -> TestTab(vm); 2 -> TripTab(vm); else -> SettingsTab(vm) }
}

@Composable
fun InfoTab(vm: ObdVm) {
    Button({ vm.loadInfo() }, Modifier.fillMaxWidth(), enabled = vm.connected && !vm.busy) { Text("خواندن اطلاعات خودرو") }
    vm.info.forEach { (k, v) -> Info(k, v) }
    Text("کیلومتر واقعی (کارکرد)، تست عملگرها و ECUهای دیگر (ABS، ایربگ، گیربکس، ایموبیلایزر) به پروتکل اختصاصی هر خودرو و دانگل مخصوص نیاز دارند و با OBD2 استاندارد ممکن نیستند.", fontSize = 12.sp)
}

@Composable
fun TestTab(vm: ObdVm) {
    Text("🔋 تست باتری و دینام", style = MaterialTheme.typography.titleMedium)
    Text("۱) سوئیچ را باز کنید (موتور خاموش) و چند ثانیه صبر کنید.\n۲) موتور را روشن کنید.\n۳) ۱۵ ثانیه بعد دور را حدود ۲۵۰۰ ببرید و ۱۰ ثانیه نگه دارید.\nنتیجه از ۳ دقیقه‌ی اخیر ضبط محاسبه می‌شود.", fontSize = 13.sp)
    Info("ولتاژ لحظه‌ای", vm.live["volt"]?.let { "%.2f V".format(it) } ?: "—")
    val rows = remember(vm.tick) { vm.recent(700).filter { it.t >= System.currentTimeMillis() - 180_000 } }
    batteryReport(rows).forEach { (k, v) -> Info(k, v) }
    HorizontalDivider()
    Text("〰️ تست پایداری دور آرام (لرزش موتور)", style = MaterialTheme.typography.titleMedium)
    Text("خودرو را در توقف و دنده‌ی خلاص، موتور گرم، بدون فشردن پدال نگه دارید و دکمه را بزنید.", fontSize = 13.sp)
    var t0 by remember { mutableStateOf<Long?>(null) }
    var res by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    LaunchedEffect(t0) { val s = t0 ?: return@LaunchedEffect; delay(20_000); res = idleReport(vm.recent(2000).filter { it.t >= s }); t0 = null }
    Button({ res = null; t0 = System.currentTimeMillis() }, Modifier.fillMaxWidth(), enabled = vm.connected && t0 == null) { Text(if (t0 != null) "در حال اندازه‌گیری… (۲۰ ثانیه)" else "شروع تست ۲۰ ثانیه‌ای") }
    res?.forEach { (k, v) -> Info(k, v) }
}

@Composable
fun TripTab(vm: ObdVm) {
    Button({ if (vm.tripOn) vm.stopTrip() else vm.startTrip() }, Modifier.fillMaxWidth(), enabled = vm.connected) {
        Text(if (vm.tripOn) "پایان و ذخیره سفر" else "شروع سفر جدید")
    }
    if (vm.tripOn) {
        Info("مسافت", "%.2f km".format(vm.tKm)); Info("سوخت مصرفی", "%.2f L".format(vm.tL))
        Info("میانگین مصرف", if (vm.tKm > 0.1) "%.1f L/100km".format(vm.tL / vm.tKm * 100) else "—")
        Info("حداکثر سرعت", "%.0f km/h".format(vm.tMax))
        LiveChart(vm)
    }
    Text("سابقه سفرها", style = MaterialTheme.typography.titleMedium)
    vm.trips.forEach { t ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(fa(t.t), fontWeight = FontWeight.Bold)
            Text("%.1f km • %.1f L • %.1f L/100km • حداکثر %.0f km/h".format(t.km, t.l, if (t.km > 0) t.l / t.km * 100 else 0.0, t.max))
        } }
    }
}

@Composable
fun SettingsTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val dec = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Text("موتور و هشدارها", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(vm.disp, { vm.disp = it; vm.save() }, label = { Text("حجم موتور (لیتر)") }, keyboardOptions = dec, singleLine = true)
    OutlinedTextField(vm.coolMax, { vm.coolMax = it; vm.save() }, label = { Text("هشدار دمای موتور (°C)") }, keyboardOptions = dec, singleLine = true)
    OutlinedTextField(vm.rpmMax, { vm.rpmMax = it; vm.save() }, label = { Text("هشدار دور موتور (rpm)") }, keyboardOptions = dec, singleLine = true)
    HorizontalDivider()
    Text("فعال ماندن در پس‌زمینه", style = MaterialTheme.typography.titleMedium)
    Text("برای اینکه سیستم اندروید برنامه را وسط مسیر نبندد، دکمه‌ی زیر را بزنید و برای Baloch OBD گزینه‌ی «بدون محدودیت / Don't optimize» را انتخاب کنید. در بعضی گوشی‌ها (شیائومی، سامسونگ، آنر) باید «اجرای خودکار» یا «Autostart» را هم روشن کنید.", fontSize = 13.sp)
    OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("تنظیمات بهینه‌سازی باتری") }
    HorizontalDivider()
    Text("کالیبراسیون مصرف سوخت", style = MaterialTheme.typography.titleMedium)
    Text("۱) باک را کامل پر کنید و «شروع شمارش» را بزنید.\n۲) رانندگی کنید (اپ وصل باشد).\n۳) دفعه بعد که باک را کامل پر کردید، لیتر واقعی را وارد و «اعمال» را بزنید.", fontSize = 13.sp)
    Info("تخمین اپ از شروع شمارش", "%.1f L".format(vm.calEst))
    Info("ضریب فعلی", "%.2f".format(vm.calib))
    var actual by remember { mutableStateOf("") }
    OutlinedTextField(actual, { actual = it }, label = { Text("لیتر واقعیِ بنزین‌زده‌شده") }, keyboardOptions = dec, singleLine = true)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton({ vm.resetCal() }) { Text("شروع شمارش") }
        Button({ vm.applyCal(num(actual) ?: 0.0) }) { Text("اعمال") }
    }
}
