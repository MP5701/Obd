@file:OptIn(ExperimentalMaterial3Api::class)

package ir.obd.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

data class Trip(val t: Long, val km: Double, val l: Double, val max: Double)

class ObdVm(app: Application) : AndroidViewModel(app) {
    private val c = ObdClient()
    private val prefs = app.getSharedPreferences("obd", 0)
    var status by mutableStateOf("متصل نیست"); var connected by mutableStateOf(false)
    var live by mutableStateOf(Live()); var lph by mutableStateOf<Double?>(null)
    var dtcs by mutableStateOf<List<String>?>(null); var busy by mutableStateOf(false)
    var proto by mutableStateOf("0"); var disp by mutableStateOf("1.6")
    var tripOn by mutableStateOf(false)
    var tKm by mutableStateOf(0.0); var tL by mutableStateOf(0.0); var tMax by mutableStateOf(0.0)
    var trips by mutableStateOf(load())
    private var job: Job? = null

    private fun load(): List<Trip> {
        val a = JSONArray(prefs.getString("trips", "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> Trip(o.getLong("t"), o.getDouble("km"), o.getDouble("l"), o.getDouble("max")) } }.reversed()
    }

    // مصرف سوخت: با MAF اگر موجود باشد، وگرنه تخمین از MAP/دور/دما (speed-density)
    private fun fuel(l: Live): Double? {
        val maf = l.maf ?: run {
            val r = l.rpm ?: return null; val m = l.map ?: return null
            val imap = r * m / ((l.iat ?: 25.0) + 273.15) / 2
            imap / 60 * 0.85 * (disp.toDoubleOrNull() ?: 1.6) * 28.97 / 8.314
        }
        return maf / (14.7 * 745) * 3600
    }

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice) {
        job?.cancel(); connected = false; status = "در حال اتصال..."
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                c.connect(d, proto); connected = true; status = "متصل: ${d.name}"
                var last = System.nanoTime()
                while (isActive) {
                    val l = c.readLive(); val now = System.nanoTime(); val dt = (now - last) / 1e9; last = now
                    live = l; val f = fuel(l); lph = f
                    if (tripOn) {
                        val v = l.speed ?: 0.0
                        tKm += v * dt / 3600; tL += (f ?: 0.0) * dt / 3600; tMax = maxOf(tMax, v)
                    }
                }
            } catch (e: Exception) {
                if (isActive) { connected = false; status = "خطا: ${e.message}" }
            }
        }
    }

    fun readDtc() = viewModelScope.launch(Dispatchers.IO) {
        busy = true; try { dtcs = c.readDtc() } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false
    }
    fun clearDtc() = viewModelScope.launch(Dispatchers.IO) {
        busy = true; try { c.clearDtc(); dtcs = emptyList() } catch (e: Exception) { status = "خطا: ${e.message}" }; busy = false
    }
    fun startTrip() { tKm = 0.0; tL = 0.0; tMax = 0.0; tripOn = true }
    fun stopTrip() {
        tripOn = false
        if (tKm > 0.05) {
            val a = JSONArray(prefs.getString("trips", "[]"))
            a.put(JSONObject().put("t", System.currentTimeMillis()).put("km", tKm).put("l", tL).put("max", tMax))
            prefs.edit().putString("trips", a.toString()).apply(); trips = load()
        }
    }
}

@Composable
fun App(vm: ObdVm = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val names = listOf("اتصال", "داشبورد", "خطاها", "سفر"); val icons = listOf("🔌", "📊", "⚠️", "🛣️")
    Scaffold(bottomBar = {
        NavigationBar { names.forEachIndexed { i, n -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(icons[i]) }, label = { Text(n) }) } }
    }) { p ->
        Column(Modifier.padding(p).padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (tab) { 0 -> ConnectTab(vm); 1 -> DashTab(vm); 2 -> DtcTab(vm); else -> TripTab(vm) }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun ConnectTab(vm: ObdVm) {
    val ctx = LocalContext.current
    val ad = remember { (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter }
    var devices by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    fun refresh() { devices = try { ad?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 31) perm.launch(Manifest.permission.BLUETOOTH_CONNECT) else refresh() }

    Text(vm.status, style = MaterialTheme.typography.titleMedium)
    Text("دانگل ELM327 را از تنظیمات بلوتوث گوشی جفت کنید (رمز: 1234 یا 0000)، سوئیچ را باز کنید و دستگاه را انتخاب کنید.")
    Text("پروتکل (برای خودروهای قدیمی‌تر مثل پراید/پژو ۴۰۵ ممکن است لازم باشد دستی انتخاب شود):")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("0" to "خودکار", "3" to "ISO 9141", "4" to "KWP آهسته", "5" to "KWP سریع", "6" to "CAN")
            .forEach { (k, n) -> FilterChip(selected = vm.proto == k, onClick = { vm.proto = k }, label = { Text(n) }) }
    }
    OutlinedTextField(vm.disp, { vm.disp = it }, label = { Text("حجم موتور (لیتر) برای تخمین مصرف") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
    if (devices.isEmpty()) Text("هیچ دستگاه جفت‌شده‌ای پیدا نشد.")
    devices.forEach { d -> Button({ vm.connect(d) }, Modifier.fillMaxWidth()) { Text(d.name ?: d.address) } }
}

@Composable
fun Gauge(value: Double?, max: Float, label: String, unit: String, modifier: Modifier = Modifier) {
    val color = MaterialTheme.colorScheme.primary; val track = MaterialTheme.colorScheme.surfaceVariant
    val frac = ((value ?: 0.0).toFloat() / max).coerceIn(0f, 1f)
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(6.dp)) {
            val st = Stroke(22f, cap = StrokeCap.Round); val o = Offset(11f, 11f); val sz = Size(size.width - 22f, size.height - 22f)
            drawArc(track, 135f, 270f, false, o, sz, style = st)
            drawArc(color, 135f, 270f * frac, false, o, sz, style = st)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value?.let { "%.0f".format(it) } ?: "—", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("$label $unit", fontSize = 12.sp)
        }
    }
}

@Composable
fun Info(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
    Text(k); Text(v, fontWeight = FontWeight.Bold)
}

@Composable
fun DashTab(vm: ObdVm) {
    val l = vm.live
    if (!vm.connected) Text("ابتدا در تب «اتصال» وصل شوید.")
    Row(Modifier.fillMaxWidth()) {
        Gauge(l.rpm?.div(1000), 8f, "دور", "×۱۰۰۰", Modifier.weight(1f))
        Gauge(l.speed, 220f, "سرعت", "km/h", Modifier.weight(1f))
    }
    Row(Modifier.fillMaxWidth()) {
        Gauge(l.coolant, 130f, "دمای آب", "°C", Modifier.weight(1f))
        Gauge(l.load, 100f, "بار موتور", "%", Modifier.weight(1f))
    }
    val f = vm.lph; val v = l.speed
    Info("مصرف لحظه‌ای", when { f == null -> "—"; v != null && v > 3 -> "%.1f L/100km".format(f / v * 100); else -> "%.1f L/h".format(f) })
    Info("دریچه گاز", l.throttle?.let { "%.0f %%".format(it) } ?: "—")
    Info("فشار مانیفولد (MAP)", l.map?.let { "%.0f kPa".format(it) } ?: "—")
    Info("دمای هوای ورودی", l.iat?.let { "%.0f °C".format(it) } ?: "—")
    Info("ولتاژ باتری", l.volt?.let { "%.1f V".format(it) } ?: "—")
}

val DTC_INFO = mapOf(
    "P0300" to "ناهمواری احتراق (misfire) تصادفی", "P0301" to "misfire سیلندر ۱", "P0302" to "misfire سیلندر ۲",
    "P0303" to "misfire سیلندر ۳", "P0304" to "misfire سیلندر ۴", "P0171" to "مخلوط رقیق", "P0172" to "مخلوط غنی",
    "P0420" to "راندمان کاتالیست پایین", "P0115" to "سنسور دمای آب", "P0105" to "سنسور MAP",
    "P0335" to "سنسور دور میل‌لنگ", "P0340" to "سنسور میل‌سوپاپ", "P0505" to "کنترل دور آرام",
    "P0562" to "ولتاژ سیستم پایین", "P0130" to "سنسور اکسیژن ۱"
)

@Composable
fun DtcTab(vm: ObdVm) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button({ vm.readDtc() }, enabled = vm.connected && !vm.busy) { Text("خواندن خطاها") }
        OutlinedButton({ vm.clearDtc() }, enabled = vm.connected && !vm.busy) { Text("پاک کردن") }
    }
    Text("توجه: پاک کردن کدها چراغ چک را خاموش می‌کند ولی مشکل را رفع نمی‌کند.", fontSize = 12.sp)
    val d = vm.dtcs
    if (d != null && d.isEmpty()) Text("هیچ خطایی ثبت نشده ✅")
    d?.forEach { code ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(code, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(DTC_INFO[code] ?: "توضیح در لیست نیست؛ کد را جست‌وجو کنید")
        } }
    }
}

fun fa(t: Long): String = android.icu.text.SimpleDateFormat("yyyy/MM/dd HH:mm", android.icu.util.ULocale("fa_IR@calendar=persian")).format(java.util.Date(t))

@Composable
fun TripTab(vm: ObdVm) {
    Button({ if (vm.tripOn) vm.stopTrip() else vm.startTrip() }, Modifier.fillMaxWidth(), enabled = vm.connected) {
        Text(if (vm.tripOn) "پایان و ذخیره سفر" else "شروع سفر جدید")
    }
    if (vm.tripOn) {
        Info("مسافت", "%.2f km".format(vm.tKm)); Info("سوخت مصرفی", "%.2f L".format(vm.tL))
        Info("میانگین مصرف", if (vm.tKm > 0.1) "%.1f L/100km".format(vm.tL / vm.tKm * 100) else "—")
        Info("حداکثر سرعت", "%.0f km/h".format(vm.tMax))
    }
    Text("سابقه سفرها", style = MaterialTheme.typography.titleMedium)
    vm.trips.forEach { t ->
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text(fa(t.t), fontWeight = FontWeight.Bold)
            Text("%.1f km • %.1f L • %.1f L/100km • حداکثر %.0f km/h".format(t.km, t.l, if (t.km > 0) t.l / t.km * 100 else 0.0, t.max))
        } }
    }
}
